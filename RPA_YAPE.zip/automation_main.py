import time
import subprocess
import sys
import os
import re
import logging

# Configuración básica de logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("automation_flow.log"),
        logging.StreamHandler()
    ]
)

def print_section(title):
    """Imprime un título de sección bien formateado para mejor visualización"""
    line = "=" * 60
    print("\n" + line)
    print(f"  {title}  ".center(60, '*'))
    print(line + "\n")

def wait_with_feedback(seconds, description=""):
    """Espera con retroalimentación visual de cuenta regresiva"""
    if description:
        print(f"\n>> Esperando {seconds} segundos {description}...")
    else:
        print(f"\n>> Esperando {seconds} segundos...")
    
    for i in range(seconds, 0, -1):
        sys.stdout.write(f"\r>> {i} segundos restantes...{'.' * (seconds - i + 1)}")
        sys.stdout.flush()
        time.sleep(1)
    print("\r>> ¡Tiempo completado!                       ")

def log_status(step_name, success, log_file):
    """Escribe el resultado de un paso en el archivo de log"""
    timestamp = time.strftime('%Y-%m-%d %H:%M:%S')
    status = "✅ ÉXITO" if success else "❌ FALLO"
    message = f"[{timestamp}] Paso: {step_name} - Resultado: {status}\n"
    
    print(message)
    log_message(message, log_file)

def log_message(message, log_file):
    """Escribe un mensaje en el archivo de log"""
    try:
        with open(log_file, 'a', encoding='utf-8') as f:
            f.write(message)
    except Exception as e:
        print(f"Error escribiendo en el archivo de log: {e}")

def verify_script_files():
    """Verifica que todos los archivos de script necesarios estén presentes"""
    required_files = [
        ("login.py", "Login"),
        ("home.py", "Home/Ver ventas"),
        ("ventas.py", "Ventas/Reporte"),
        ("correo.py", "Correo"),
        ("enviar.py", "Enviar"),
        ("Entendido.py", "Entendido"),
        ("validacon.py", "Validación de sesión")
    ]
    
    all_files_exist = True
    
    print_section("VERIFICANDO ARCHIVOS DE SCRIPT")
    
    for file_name, description in required_files:
        if os.path.exists(file_name):
            print(f"✅ {file_name} ({description}) - Encontrado")
        else:
            print(f"❌ {file_name} ({description}) - No encontrado")
            all_files_exist = False
    
    if not all_files_exist:
        print("\n⚠️ ADVERTENCIA: Algunos archivos de script no se encontraron.")
        print("Asegúrate de que todos los archivos estén en el mismo directorio y tengan los nombres correctos.")
        
        decision = input("\n¿Deseas continuar de todos modos? (s/n): ").lower()
        if decision != 's':
            print("Operación cancelada.")
            return False
    
    return True

def check_session_validation():
    """
    Ejecuta el script de validación para verificar si la sesión sigue activa
    Retorna True si se detectó y confirmó fin de sesión, False en caso contrario
    """
    print_section("VALIDACIÓN DE SESIÓN")
    try:
        # Ejecutar el script de validación y capturar su salida
        validacon_log_file = "monitor_entendido.log"
        
        # Verificar el tamaño del archivo de log antes de ejecutar la validación
        pre_size = 0
        if os.path.exists(validacon_log_file):
            pre_size = os.path.getsize(validacon_log_file)
        
        # Ejecutar la validación
        import validacon
        # Intentamos llamar a la función correcta del módulo validacon
        if hasattr(validacon, 'main'):
            result = validacon.main()
        else:
            # Si no hay función main(), intentamos otras funciones comunes
            possible_functions = ['check_session', 'validate', 'validate_session', 
                                 'check', 'run', 'execute', 'process']
            
            for func_name in possible_functions:
                if hasattr(validacon, func_name):
                    result = getattr(validacon, func_name)()
                    print(f"✓ Usando función '{func_name}()' del módulo validacon")
                    break
            else:
                # Si no se encuentra ninguna función conocida, ejecutamos el módulo directamente
                print("⚠️ No se encontró una función específica en validacon.py, ejecutando el módulo completo")
                exec("import validacon")
        
        # Verificar si hubo cambios en el archivo de log
        session_ended = False
        success_pattern = r"\[EXITO\] Botón ENTENDIDO presionado correctamente"
        no_session_end_pattern = r"Mensaje de sesión terminada NO confirmado \(solo \d+ frases coincidentes\)"
        tap_success_pattern = r"Tap exitoso en \(\d+, \d+\)"
        
        if os.path.exists(validacon_log_file):
            # Esperar un momento para asegurar que el archivo se ha escrito completamente
            time.sleep(0.5)
            
            # Leer solo las líneas nuevas añadidas durante esta ejecución
            try:
                # Intentar con UTF-8 primero
                with open(validacon_log_file, 'r', encoding='utf-8', errors='ignore') as f:
                    if pre_size > 0:
                        f.seek(pre_size)
                    log_content = f.read()
            except UnicodeDecodeError:
                # Si falla UTF-8, intentar con latin-1 (que acepta cualquier byte)
                with open(validacon_log_file, 'r', encoding='latin-1') as f:
                    if pre_size > 0:
                        f.seek(pre_size)
                    log_content = f.read()
            
            # Verificar patrones específicos
            if re.search(success_pattern, log_content):
                print("⚠️ [DETECTADO] Botón ENTENDIDO presionado correctamente - FIN DE SESIÓN CONFIRMADO")
                session_ended = True
            elif re.search(tap_success_pattern, log_content):
                print("🔄 [DETECTADO] Tap exitoso - Ejecutando login.py en 20 segundos...")
                # Registrar en un archivo de log separado para evitar problemas de codificación
                try:
                    with open("automation_flow.log", 'a', encoding='utf-8') as f_log:
                        f_log.write("\n=== TAP EXITOSO DETECTADO - EJECUTANDO LOGIN EN 20 SEGUNDOS ===\n")
                except Exception as e:
                    print(f"Error al escribir en el log: {e}")
                
                # En lugar de solo ejecutar login y devolver True, vamos a reiniciar todo el proceso
                # Esperamos los 20 segundos solicitados
                wait_with_feedback(20, "antes de reiniciar todo el proceso desde login")
                
                # Marcamos como fin de sesión para que el bucle principal reinicie todo el proceso
                # Esto hará que salga del bucle interno y reinicie todo desde login
                print_section("REINICIANDO PROCESO COMPLETO TRAS DETECTAR TAP EXITOSO")
                log_message("\n=== REINICIANDO PROCESO COMPLETO TRAS DETECTAR TAP EXITOSO ===\n", "automation_flow.log")
                return True
                
            elif re.search(no_session_end_pattern, log_content):
                print("✅ Mensaje de sesión terminada NO confirmado - Continuando normalmente")
                session_ended = False
        
        return session_ended
        
    except Exception as e:
        print(f"❌ Error ejecutando validación: {str(e)}")
        import traceback
        traceback.print_exc()
        return False  # En caso de error, asumimos que continuamos normal

def run_login():
    """Ejecuta el script de login y maneja su resultado"""
    print_section("PASO 1: LOGIN")
    try:
        # Importamos el módulo dentro de la función para evitar problemas de importación
        import login
        
        # Ejecutamos el login
        login_result = login.main()
        
        # IMPORTANTE: Verificamos explícitamente el resultado
        # Algunos scripts pueden no devolver un valor específico al completarse exitosamente
        if login_result is None:  # Si no devuelve nada, asumimos éxito
            print("✅ Login completado (sin valor de retorno explícito)")
            return True
        elif isinstance(login_result, bool):  # Si devuelve un booleano
            if login_result:
                print("✅ Login completado exitosamente")
            else:
                print("❌ Login falló según el valor retornado")
            return login_result
        else:  # Si devuelve otro tipo de valor
            print(f"✅ Login completado (valor de retorno: {login_result})")
            return True
    except Exception as e:
        print(f"❌ Error ejecutando login: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

def run_home():
    """Ejecuta el script de home y maneja su resultado"""
    print_section("PASO 2: HOME - CLICK EN VER VENTAS")
    try:
        import home
        result = home.click_ver_ventas()
        if result is None:
            print("✅ Home completado (sin valor de retorno explícito)")
            return True
        return result if isinstance(result, bool) else True
    except Exception as e:
        print(f"❌ Error ejecutando home: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

def run_ventas():
    """Ejecuta el script de ventas y maneja su resultado"""
    print_section("PASO 3: VENTAS - CLICK EN REPORTE")
    try:
        import ventas
        result = ventas.click_reporte()
        if result is None:
            print("✅ Ventas completado (sin valor de retorno explícito)")
            return True
        return result if isinstance(result, bool) else True
    except Exception as e:
        print(f"❌ Error ejecutando ventas: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

def run_correo():
    """Ejecuta el script de correo y maneja su resultado"""
    print_section("PASO 4: CORREO - LIMPIAR Y ESCRIBIR EMAIL")
    try:
        import correo
        result = correo.clear_and_write_email()
        if result is None:
            print("✅ Correo completado (sin valor de retorno explícito)")
            return True
        return result if isinstance(result, bool) else True
    except Exception as e:
        print(f"❌ Error ejecutando correo: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

def run_enviar():
    """Ejecuta el script de enviar y maneja su resultado"""
    print_section("PASO 5: BOTÓN ENVIAR")
    try:
        import enviar
        result = enviar.main()
        if result is None:
            print("✅ Enviar completado (sin valor de retorno explícito)")
            return True
        return result if isinstance(result, bool) else True
    except Exception as e:
        print(f"❌ Error ejecutando enviar: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

def run_entendido():
    """Ejecuta el script de entendido y maneja su resultado"""
    print_section("PASO 6: BOTÓN ENTENDIDO")
    try:
        import Entendido
        result = Entendido.tap_entendido_button()
        if result is None:
            print("✅ Entendido completado (sin valor de retorno explícito)")
            return True
        return result if isinstance(result, bool) else True
    except Exception as e:
        print(f"❌ Error ejecutando entendido: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

def handle_session_end(log_file):
    """Maneja el fin de sesión, esperando 1 minuto antes de reiniciar"""
    print_section("SESIÓN FINALIZADA - ESPERA DE 1 MINUTO ANTES DE REINICIAR")
    log_message("\n=== SESIÓN FINALIZADA - ESPERA DE 1 MINUTO ANTES DE REINICIAR ===\n", log_file)
    wait_with_feedback(60, "antes de reiniciar desde login")  # Espera de 1 minuto (60 segundos)
    return True

def run_infinite_flow():
    """Ejecuta el flujo completo infinitamente hasta que se detenga manualmente"""
    print_section("INICIANDO FLUJO AUTOMATIZADO INFINITO")
    print("El proceso continuará indefinidamente hasta que lo detengas con Ctrl+C")
    
    # Crear un directorio para los logs si no existe
    log_dir = "automation_logs"
    os.makedirs(log_dir, exist_ok=True)
    
    # Archivo de log para registrar el progreso
    log_file = os.path.join(log_dir, f"automation_log_{time.strftime('%Y%m%d_%H%M%S')}.txt")
    
    try:
        with open(log_file, 'w', encoding='utf-8') as f:
            f.write(f"=== Log de automatización iniciado: {time.strftime('%Y-%m-%d %H:%M:%S')} ===\n\n")
    except Exception as e:
        print(f"Error creando archivo de log: {e}")
    
    try:
        # Contador de ciclos totales completados (solo para seguimiento)
        completed_cycles = 0
        
        # Ciclo principal infinito
        while True:
            # PASO 1: Login (se ejecuta al inicio y cada vez que se detecta fin de sesión)
            login_result = run_login()
            log_status("Login", login_result, log_file)
            
            if not login_result:
                print("❌ Login falló. Intentando reiniciar el proceso.")
                wait_with_feedback(15, "antes de reintentar el login")
                continue
            
            # Esperar a que la pantalla se estabilice después del login
            wait_with_feedback(10, "después del login")
            
            # Iteraciones dentro del ciclo actual de sesión
            iterations_in_session = 0
            
            # Bucle de iteraciones para esta sesión (infinito hasta detectar fin de sesión)
            while True:
                iterations_in_session += 1
                completed_cycles += 1
                
                print_section(f"INICIANDO CICLO #{completed_cycles} (#{iterations_in_session} en esta sesión)")
                log_message(f"\n=== INICIANDO CICLO #{completed_cycles} (#{iterations_in_session} en esta sesión) ===\n", log_file)
                
                # PASO 2: Home/Ver ventas
                home_result = run_home()
                log_status("Home (Ver ventas)", home_result, log_file)
                
                if not home_result:
                    print("⚠️ Click en Ver ventas falló. Intentando continuar...")
                
                wait_with_feedback(5, "después de clic en Ver ventas")
                
                # VALIDACIÓN ANTES DEL PASO VENTAS
                print_section("VALIDACIÓN ANTES DE VENTAS")
                session_ended = check_session_validation()
                log_status("Validación pre-Ventas", not session_ended, log_file)
                if session_ended:
                    handle_session_end(log_file)
                    break  # Salir del bucle de iteraciones para reiniciar desde login
                
                # PASO 3: Ventas/Reporte
                reporte_result = run_ventas()
                log_status("Ventas (Reporte)", reporte_result, log_file)
                
                if not reporte_result:
                    print("⚠️ Click en Reporte falló. Intentando continuar...")
                
                wait_with_feedback(2, "después de clic en Reporte")
                
                # VALIDACIÓN ANTES DEL PASO CORREO
                print_section("VALIDACIÓN ANTES DE CORREO")
                session_ended = check_session_validation()
                log_status("Validación pre-Correo", not session_ended, log_file)
                if session_ended:
                    handle_session_end(log_file)
                    break  # Salir del bucle de iteraciones para reiniciar desde login
                
                # PASO 4: Correo
                email_result = run_correo()
                log_status("Correo", email_result, log_file)
                
                if not email_result:
                    print("⚠️ Operación de correo falló. Intentando continuar...")
                
                wait_with_feedback(2, "después de escribir correo")
                
                # VALIDACIÓN ANTES DEL PASO ENVIAR
                print_section("VALIDACIÓN ANTES DE ENVIAR")
                session_ended = check_session_validation()
                log_status("Validación pre-Enviar", not session_ended, log_file)
                if session_ended:
                    handle_session_end(log_file)
                    break  # Salir del bucle de iteraciones para reiniciar desde login
                
                # PASO 5: Enviar
                send_result = run_enviar()
                log_status("Enviar", send_result, log_file)
                
                if not send_result:
                    print("⚠️ Click en Enviar falló. Intentando continuar...")
                
                wait_with_feedback(2, "después de clic en Enviar")
                
                # VALIDACIÓN ANTES DEL PASO ENTENDIDO
                print_section("VALIDACIÓN ANTES DE ENTENDIDO")
                session_ended = check_session_validation()
                log_status("Validación pre-Entendido", not session_ended, log_file)
                if session_ended:
                    handle_session_end(log_file)
                    break  # Salir del bucle de iteraciones para reiniciar desde login
                
                # PASO 6: Entendido
                entendido_result = run_entendido()
                log_status("Entendido", entendido_result, log_file)
                
                if not entendido_result:
                    print("⚠️ Click en Entendido falló. Intentando continuar...")
                
                # Esperar un poco antes de iniciar la siguiente iteración
                wait_with_feedback(3, "antes de iniciar la siguiente iteración")
                
                # Validación final para verificar si la sesión terminó durante la iteración
                session_ended = check_session_validation()
                if session_ended:
                    handle_session_end(log_file)
                    break  # Salir del bucle de iteraciones para reiniciar desde login
            
            # Si llegamos aquí es porque se detectó fin de sesión 
            # y debemos reiniciar desde login en el bucle principal
            print_section("REINICIANDO DESDE LOGIN")
            log_message("\n=== REINICIANDO DESDE LOGIN ===\n", log_file)
        
    except KeyboardInterrupt:
        print("\n\n")
        print_section("PROCESO INTERRUMPIDO POR EL USUARIO")
        print(f"Se completaron {completed_cycles} ciclos en total antes de la interrupción.")
        log_message(f"\n=== PROCESO INTERRUMPIDO POR EL USUARIO ===\n", log_file)
        log_message(f"Se completaron {completed_cycles} ciclos en total antes de la interrupción.\n", log_file)
        return False
    except Exception as e:
        print(f"\n\n❌ ERROR INESPERADO: {str(e)}")
        import traceback
        error_details = traceback.format_exc()
        print(error_details)
        log_message(f"\n=== ERROR INESPERADO ===\n{error_details}\n", log_file)
        return False

if __name__ == "__main__":
    # Verificar que los archivos estén presentes
    if verify_script_files():
        # Mostrar mensaje informativo sobre la ejecución infinita
        print("\n¡ATENCIÓN! Este script se ejecutará infinitamente hasta que lo detengas manualmente con Ctrl+C.")
        confirmar = input("¿Deseas continuar? (s/n): ").lower()
        
        if confirmar == 's':
            # Ejecutar el flujo infinito
            run_infinite_flow()
        else:
            print("Operación cancelada por el usuario.")