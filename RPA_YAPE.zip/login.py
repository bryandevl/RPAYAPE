import cv2
import pytesseract
import subprocess
import os
import tempfile
from time import sleep
import numpy as np
import random


pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'  # Comenta esta línea en Linux/Mac


TARGET_SEQUENCE = "205153"
MAX_RETRIES = 5  # Número máximo de intentos para la detección completa
SCREENSHOT_DIR = tempfile.gettempdir()
SCREENSHOT_PATH = os.path.join(SCREENSHOT_DIR, "yape_screen.png")
DEBUG_DIR = os.path.join(tempfile.gettempdir(), "yape_debug")


os.makedirs(DEBUG_DIR, exist_ok=True)


FALLBACK_POSITIONS = {
    '0': (540, 1500),
    '1': (300, 1200),
    '2': (540, 1200),
    '3': (800, 1500),
    '4': (300, 1350),
    '5': (800, 1200),
    '6': (540, 1350),
    '7': (300, 1500),
    '8': (540, 1350),
    '9': (800, 1350)
}

def capture_screen():
    """Captura mejorada con validación"""
    try:
        subprocess.run(
            f"adb exec-out screencap -p > {SCREENSHOT_PATH}", 
            shell=True, 
            check=True,
            timeout=10
        )
        if not os.path.exists(SCREENSHOT_PATH) or os.path.getsize(SCREENSHOT_PATH) == 0:
            raise Exception("Captura vacía o fallida")
        print("✅ Captura de pantalla exitosa")
    except subprocess.TimeoutExpired:
        raise Exception("Timeout al capturar pantalla")
    except Exception as e:
        raise Exception(f"Error capturando pantalla: {str(e)}")

def save_debug_image(img, name):
    """Guarda imágenes para debugging"""
    path = os.path.join(DEBUG_DIR, f"{name}.png")
    cv2.imwrite(path, img)
    print(f"Imagen de debug guardada: {path}")

def try_multiple_preprocessings():
    """Prueba múltiples métodos de preprocesamiento"""
    try:
        original = cv2.imread(SCREENSHOT_PATH)
        if original is None:
            raise Exception("No se pudo leer la imagen original")
            
       
        save_debug_image(original, "01_original")
        
        # Mejora: Prueba diferentes áreas para la detección del teclado
        h, w = original.shape[:2]
        
        # Áreas diferentes para el teclado - probamos varias regiones
        keypad_areas = [
            original[int(h*0.55):int(h*0.9), int(w*0.1):int(w*0.9)],  # Original
            original[int(h*0.5):int(h*0.95), int(w*0.05):int(w*0.95)],  # Un poco más grande
            original[int(h*0.6):int(h*0.85), int(w*0.15):int(w*0.85)]   # Un poco más pequeña
        ]
        
        processed_images = []
        
        for i, keypad_area in enumerate(keypad_areas):
            save_debug_image(keypad_area, f"02_keypad_area_{i}")
            
            # Procesamiento en escala de grises
            gray = cv2.cvtColor(keypad_area, cv2.COLOR_BGR2GRAY)
            blurred = cv2.GaussianBlur(gray, (5, 5), 0)
            
            # Umbralización adaptativa
            thresh1 = cv2.adaptiveThreshold(blurred, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, 
                                          cv2.THRESH_BINARY, 11, 2)
            save_debug_image(thresh1, f"03_adaptive_thresh_{i}")
            
            # Umbralización Otsu
            _, thresh2 = cv2.threshold(blurred, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
            save_debug_image(thresh2, f"04_otsu_thresh_{i}")
            
            # Detección de bordes
            edges = cv2.Canny(blurred, 50, 150)
            dilated = cv2.dilate(edges, np.ones((3,3), np.uint8), iterations=1)
            save_debug_image(dilated, f"05_edges_{i}")
            
            # Mejora: Umbralización inversa (para fondos oscuros)
            _, thresh_inv = cv2.threshold(blurred, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
            save_debug_image(thresh_inv, f"06_inverse_thresh_{i}")
            
            # Agregar todas las imágenes procesadas
            processed_images.extend([
                (f"keypad_{i}", keypad_area),
                (f"adaptive_{i}", thresh1),
                (f"otsu_{i}", thresh2),
                (f"edges_{i}", dilated),
                (f"inverse_{i}", thresh_inv)
            ])
        
        return processed_images
    except Exception as e:
        raise Exception(f"Error en preprocesamiento: {str(e)}")

def extract_numbers_from_images(image_list):
    """Intenta extraer números de múltiples imágenes preprocesadas"""
    all_numbers = {}
    
    for name, img in image_list:
        try:
            # Diferentes configuraciones de OCR según el tipo de imagen
            if "edges" in name:
                config = '--psm 11 --oem 3 -c tessedit_char_whitelist=0123456789'
            elif "inverse" in name:
                config = '--psm 10 --oem 3 -c tessedit_char_whitelist=0123456789'
            else:
                # Probar diferentes modos PSM para mejorar detección
                configs = [
                    '--psm 6 --oem 3 -c tessedit_char_whitelist=0123456789',
                    '--psm 7 --oem 3 -c tessedit_char_whitelist=0123456789',
                    '--psm 8 --oem 3 -c tessedit_char_whitelist=0123456789',
                    '--psm 10 --oem 3 -c tessedit_char_whitelist=0123456789'
                ]
                
                # Usar la primera configuración por defecto
                config = configs[0]
                
                # Si esta imagen ya se ha procesado antes sin éxito, probar otro modo PSM
                if "retry" in name:
                    retry_num = int(name.split("_")[-1])
                    config = configs[retry_num % len(configs)]
            
            data = pytesseract.image_to_data(img, output_type=pytesseract.Output.DICT, config=config)
            
            # Calcular offsets basados en el nombre de la imagen
            offset_y = 0
            offset_x = 0
            
            if "keypad" not in name or "_" in name:
                h, w = cv2.imread(SCREENSHOT_PATH).shape[:2]
                area_idx = 0
                if "_" in name:
                    try:
                        area_idx = int(name.split("_")[-1])
                    except:
                        pass
                
                if area_idx == 0:
                    offset_y, offset_x = int(h*0.55), int(w*0.1)
                elif area_idx == 1:
                    offset_y, offset_x = int(h*0.5), int(w*0.05)
                elif area_idx == 2:
                    offset_y, offset_x = int(h*0.6), int(w*0.15)
            
            # Extraer textos detectados
            for i, text in enumerate(data['text']):
                if text.isdigit() and len(text) == 1 and float(data['conf'][i]) > 50:  # Umbral de confianza reducido
                    x = offset_x + data['left'][i] + data['width'][i] // 2
                    y = offset_y + data['top'][i] + data['height'][i] // 2
                    
                    # Solo actualizar si tiene mayor confianza
                    if text in all_numbers:
                        current_conf = all_numbers[text][2]
                        if float(data['conf'][i]) <= current_conf:
                            continue
                    
                    all_numbers[text] = (x, y, float(data['conf'][i]))
                    print(f"Detectado '{text}' en ({x}, {y}) con confianza {data['conf'][i]}")
            
        except Exception as e:
            print(f"Error en OCR para {name}: {str(e)}")
    
    return {k: (v[0], v[1]) for k, v in all_numbers.items()} if all_numbers else None

def detect_numbers_by_contours():
    """Método alternativo usando detección de contornos para círculos"""
    try:
        img = cv2.imread(SCREENSHOT_PATH)
        if img is None:
            return None
            
        # Convertir a escala de grises
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        blurred = cv2.GaussianBlur(gray, (5, 5), 0)
        
        # Mejorado: Probar diferentes parámetros para la detección de círculos
        contour_numbers = {}
        
        # Lista de parámetros a probar
        params_list = [
            # dp, minDist, param1, param2, minRadius, maxRadius
            (1, 50, 50, 30, 30, 70),
            (1, 40, 40, 20, 25, 80),
            (1.2, 60, 60, 35, 35, 65)
        ]
        
        for param_idx, (dp, minDist, param1, param2, minRadius, maxRadius) in enumerate(params_list):
            circles = cv2.HoughCircles(
                blurred, cv2.HOUGH_GRADIENT, dp=dp, minDist=minDist,
                param1=param1, param2=param2, minRadius=minRadius, maxRadius=maxRadius
            )
            
            if circles is not None:
                circles = np.round(circles[0, :]).astype("int")
                
                # Imagen para visualización
                vis_img = img.copy()
                
                # Ordenar círculos por posición (aproximadamente filas y columnas)
                circles = sorted(circles, key=lambda x: (x[1] // 100, x[0]))
                
                # Mapa de teclado numérico típico
                keypad_layout = [
                    '1', '2', '3',
                    '4', '5', '6',
                    '7', '8', '9',
                    '*', '0', '#'
                ]
                
                temp_numbers = {}
                for i, (x, y, r) in enumerate(circles[:12]):  # Limitar a 12 círculos (teclado numérico)
                    if i < len(keypad_layout):
                        number = keypad_layout[i]
                        if number.isdigit():
                            temp_numbers[number] = (x, y)
                            # Marcar en la imagen de depuración
                            cv2.circle(vis_img, (x, y), r, (0, 255, 0), 2)
                            cv2.putText(vis_img, number, (x-10, y), 
                                        cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
                
                save_debug_image(vis_img, f"06_circle_detection_{param_idx}")
                
                # Si detectamos más números que antes, actualizar nuestro conjunto
                if len(temp_numbers) > len(contour_numbers):
                    contour_numbers = temp_numbers
                    
                # Si ya tenemos todos los números necesarios, podemos parar
                if all(n in contour_numbers for n in TARGET_SEQUENCE):
                    break
        
        return contour_numbers if contour_numbers else None
    except Exception as e:
        print(f"Error en detección de contornos: {str(e)}")
        return None

def try_angle_corrections():
    """Intenta corregir la imagen girándola en diferentes ángulos"""
    try:
        img = cv2.imread(SCREENSHOT_PATH)
        if img is None:
            return None
            
        angles = [1, -1, 2, -2, 3, -3]
        all_processed = []
        
        for angle_idx, angle in enumerate(angles):
            # Girar la imagen
            h, w = img.shape[:2]
            center = (w // 2, h // 2)
            rotation_matrix = cv2.getRotationMatrix2D(center, angle, 1.0)
            rotated = cv2.warpAffine(img, rotation_matrix, (w, h), flags=cv2.INTER_LINEAR)
            
            save_debug_image(rotated, f"07_rotated_{angle}")
            
            # Procesar la imagen rotada
            h, w = rotated.shape[:2]
            keypad_area = rotated[int(h*0.55):int(h*0.9), int(w*0.1):int(w*0.9)]
            
            gray = cv2.cvtColor(keypad_area, cv2.COLOR_BGR2GRAY)
            blurred = cv2.GaussianBlur(gray, (5, 5), 0)
            
            _, thresh = cv2.threshold(blurred, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
            
            all_processed.append((f"rotated_otsu_{angle_idx}", thresh))
        
        return all_processed
    except Exception as e:
        print(f"Error en corrección de ángulo: {str(e)}")
        return None

def tap_screen(x, y):
    """Tap con reintentos y feedback visual"""
    try:
        # Imagen de depuración pre-tap
        pre_tap = cv2.imread(SCREENSHOT_PATH)
        
        # Marcar el punto donde se va a tocar
        if pre_tap is not None:
            cv2.circle(pre_tap, (x, y), 20, (0, 0, 255), -1)
            save_debug_image(pre_tap, f"tap_at_{x}_{y}")
        
        # Reintentar el tap varias veces si falla
        for attempt in range(3):
            try:
                subprocess.run(
                    f"adb shell input tap {x} {y}",
                    shell=True,
                    check=True,
                    timeout=5
                )
                print(f"✓ Tap exitoso en ({x}, {y})")
                sleep(0.5)  # Pequeña pausa entre taps
                return True
            except subprocess.TimeoutExpired:
                print(f"Reintento {attempt+1} para tap en ({x}, {y})")
                sleep(1)
        
        raise Exception(f"Falló después de 3 intentos")
    except Exception as e:
        print(f"⚠️ Error al hacer tap en ({x}, {y}): {str(e)}")
        return False

def perform_minor_interaction():
    """Realiza una interacción menor para refrescar la pantalla"""
    try:
        # Opciones para tocar ligeramente la pantalla para refrescarla
        # sin afectar al teclado numérico
        h, w = cv2.imread(SCREENSHOT_PATH).shape[:2]
        
        # Tocar en la parte superior de la pantalla
        x = random.randint(w//4, 3*w//4)
        y = random.randint(h//10, h//5)
        
        subprocess.run(
            f"adb shell input tap {x} {y}",
            shell=True,
            check=True,
            timeout=3
        )
        print(f"ℹ️ Interacción menor en ({x}, {y}) para refrescar pantalla")
        sleep(0.5)
        return True
    except Exception as e:
        print(f"⚠️ Error en interacción menor: {str(e)}")
        return False

def main():
    success = False
    attempt = 0
    
    print("\n=== Iniciando proceso de reconocimiento de números en Yape ===")
    
    while not success and attempt < MAX_RETRIES:
        attempt += 1
        print(f"\n--- Intento {attempt} de {MAX_RETRIES} ---")
        
        try:
            # Capturar pantalla
            capture_screen()
            
            # Paso 1: Procesar imágenes y extraer números mediante OCR
            preprocessed_images = try_multiple_preprocessings()
            numbers = extract_numbers_from_images(preprocessed_images)
            
            # Verificar si se reconocieron todos los números necesarios
            if numbers:
                missing = [n for n in TARGET_SEQUENCE if n not in numbers]
                if not missing:
                    print("✅ Todos los números del PIN fueron detectados por OCR")
                    # Ingresar la secuencia
                    for num in TARGET_SEQUENCE:
                        tap_screen(*numbers[num])
                    print("✅ Secuencia completa ingresada usando OCR")
                    success = True
                    break
                else:
                    print(f"⚠️ Faltan números por OCR: {missing}")
                    print(f"Números detectados hasta ahora: {sorted(numbers.keys())}")
                    
                    # Paso 2: Si faltan números, intentar detección de contornos
                    contour_numbers = detect_numbers_by_contours()
                    
                    if contour_numbers:
                        # Combinar resultados de OCR y contornos
                        for num, pos in contour_numbers.items():
                            if num not in numbers:
                                numbers[num] = pos
                        
                        # Verificar si ahora tenemos todos los números
                        missing = [n for n in TARGET_SEQUENCE if n not in numbers]
                        if not missing:
                            print("✅ Todos los números del PIN detectados combinando OCR y contornos")
                            for num in TARGET_SEQUENCE:
                                tap_screen(*numbers[num])
                            print("✅ Secuencia completa ingresada")
                            success = True
                            break
                        else:
                            print(f"⚠️ Aún faltan números: {missing}")
                    
                    # Paso 3: Probar con corrección de ángulo si aún faltan números
                    if not success:
                        print("Intentando con corrección de ángulo...")
                        rotated_images = try_angle_corrections()
                        if rotated_images:
                            rotated_numbers = extract_numbers_from_images(rotated_images)
                            if rotated_numbers:
                                # Combinar con números existentes
                                for num, pos in rotated_numbers.items():
                                    if num not in numbers:
                                        numbers[num] = pos
                                
                                # Verificar si ahora tenemos todos los números
                                missing = [n for n in TARGET_SEQUENCE if n not in numbers]
                                if not missing:
                                    print("✅ Todos los números del PIN detectados después de corrección de ángulo")
                                    for num in TARGET_SEQUENCE:
                                        tap_screen(*numbers[num])
                                    print("✅ Secuencia completa ingresada")
                                    success = True
                                    break
            else:
                print("⚠️ No se detectaron números por OCR")
            
            # Si aún no tenemos éxito, realizar una interacción menor y reintentar
            if not success:
                print("Realizando interacción menor para refrescar pantalla...")
                perform_minor_interaction()
                sleep(1)  # Esperar un poco para que se actualice la UI
        
        except Exception as e:
            print(f"⚠️ Error en intento {attempt}: {str(e)}")
        
        # Breve pausa entre intentos
        if not success and attempt < MAX_RETRIES:
            print(f"Esperando antes del siguiente intento...")
            sleep(2)
    
    # Si después de todos los intentos no se tuvo éxito, usar posiciones predefinidas
    if not success:
        print("\n⚠️ Todos los métodos de detección fallaron después de múltiples intentos")
        print("Usando coordenadas fijas como último recurso...")
        for num in TARGET_SEQUENCE:
            tap_screen(*FALLBACK_POSITIONS[num])
        print("✅ Secuencia completa ingresada usando coordenadas predefinidas")

    print("\n=== Proceso completado ===")
    print(f"Imágenes de debug disponibles en: {DEBUG_DIR}")

if __name__ == "__main__":
    main()