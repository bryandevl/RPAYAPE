import cv2
import numpy as np
import subprocess
from time import sleep
import pytesseract
import re
import os

# Crear carpeta de imágenes si no existe
if not os.path.exists("imagenes"):
    os.makedirs("imagenes")
    print("✅ Carpeta 'imagenes' creada correctamente")


pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'


def capture_screen():
    """Captura la pantalla del dispositivo en tiempo real y la retorna como una imagen en memoria."""
    try:
        screenshot = subprocess.run(
            "adb exec-out screencap -p", 
            shell=True, 
            stdout=subprocess.PIPE,
            check=True,
            timeout=10
        ).stdout

        img = np.asarray(bytearray(screenshot), dtype=np.uint8)
        img = cv2.imdecode(img, cv2.IMREAD_COLOR)

        if img is None:
            raise Exception("Error al convertir la captura de pantalla en imagen")
        
        print("✅ Captura de pantalla exitosa")
        return img
    except subprocess.TimeoutExpired:
        raise Exception("Timeout al capturar pantalla")
    except Exception as e:
        raise Exception(f"Error capturando pantalla: {str(e)}")


def preprocess_image_for_ocr(img, debug=False):
    """Preprocesa la imagen para mejorar la detección OCR."""
    # Convertir a escala de grises
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    
    # Aplicar umbral adaptativo
    binary = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, 
                                  cv2.THRESH_BINARY, 11, 2)
    
    # Operación morfológica para mejorar texto
    kernel = np.ones((1, 1), np.uint8)
    binary = cv2.morphologyEx(binary, cv2.MORPH_CLOSE, kernel)
    
    if debug:
        cv2.imwrite(os.path.join("imagenes", "adaptive_threshold.png"), binary)
    
    return binary


def clean_text(text):
    """Limpia el texto detectado para eliminar caracteres no deseados."""
    # Solo mantener letras (incluyendo acentuadas), números y espacios
    cleaned_text = re.sub(r'[^\w\sáéíóúÁÉÍÓÚñÑ]', '', text)
    # Eliminar el carácter © específicamente
    cleaned_text = cleaned_text.replace('©', '')
    # Eliminar múltiples espacios y espacios al inicio/final
    cleaned_text = re.sub(r'\s+', ' ', cleaned_text).strip()
    return cleaned_text


def calculate_text_similarity(text1, text2):
    """Calcula la similitud entre dos textos."""
    # Convertir a minúsculas y quitar espacios para comparación
    text1 = text1.lower().replace(" ", "")
    text2 = text2.lower().replace(" ", "")
    
    # Si uno contiene al otro, calcular similitud basada en longitud
    if text1 in text2:
        return len(text1) / len(text2) * 100
    elif text2 in text1:
        return len(text2) / len(text1) * 100
    
    # Calcular caracteres comunes
    min_len = min(len(text1), len(text2))
    if min_len == 0:
        return 0
    
    common_chars = sum(c1 == c2 for c1, c2 in zip(text1, text2[:min_len]))
    similarity = (common_chars / min_len) * 100
    
    return similarity


def find_text_and_click(img, target_text="Ver ventas", min_length=3, min_confidence=60, allow_partial=True):
    """Busca el texto especificado en la imagen y devuelve las coordenadas si lo encuentra."""
    try:
        processed_img = preprocess_image_for_ocr(img, debug=True)
        debug_img = img.copy()
        
        # Dividir el texto objetivo para buscar coincidencias parciales si se permite
        target_words = target_text.lower().split()
        clean_target = target_text.lower().replace(" ", "")
        
        # Configuración OCR para palabras individuales
        custom_config = '--oem 3 --psm 11'
        data = pytesseract.image_to_data(processed_img, output_type=pytesseract.Output.DICT, config=custom_config, lang='spa')
        
        print(f"Palabras encontradas por OCR: {len(data['text'])}")
        
        # Inicializar listas para coincidencias completas y parciales
        complete_matches = []
        partial_matches = []
        
        # Primer intento - buscar coincidencias exactas a nivel de palabra
        for i, word in enumerate(data['text']):
            # Ignorar palabras muy cortas
            if len(word.strip()) < min_length:
                continue
                
            # Limpiar y procesar la palabra
            cleaned_word = clean_text(word)
            
            if not cleaned_word.strip():
                continue
                
            # Obtener datos de posición y confianza
            x = data['left'][i]
            y = data['top'][i]
            w = data['width'][i]
            h = data['height'][i]
            conf = data['conf'][i]
            
            # Solo considerar resultados con buena confianza
            if conf < 55:  # Umbral de confianza reducido para detectar más palabras
                continue
                
            print(f"Palabra: '{cleaned_word}', Confianza: {conf}, Pos: ({x}, {y}, {w}, {h})")
            
            # Dibujar rectángulo para depuración
            cv2.rectangle(debug_img, (x, y), (x + w, y + h), (0, 255, 0), 2)
            cv2.putText(debug_img, cleaned_word, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)
            
            # Calcular similitud con texto completo
            clean_word_nospace = cleaned_word.lower().replace(" ", "")
            similarity = calculate_text_similarity(clean_word_nospace, clean_target)
            
            # Solo agregar si hay buena similitud
            if similarity > 80:  # Alta similitud para coincidencia completa
                complete_matches.append((i, similarity, cleaned_word, conf))
            # Comprobar coincidencias parciales si está permitido
            elif allow_partial:
                # Verificar si la palabra coincide con alguna de las palabras objetivo
                for target_word in target_words:
                    word_similarity = calculate_text_similarity(clean_word_nospace, target_word)
                    if word_similarity > 75 and target_word == "ventas" and "venta" in clean_word_nospace:
                        # Si coincide con "ventas", guardar como coincidencia parcial
                        partial_matches.append((i, word_similarity, cleaned_word, conf))
                        break
        
        # Guardar imagen de depuración
        cv2.imwrite("debug_ocr.png", debug_img)
        
        # Primero verificar si tenemos coincidencias completas
        if complete_matches:
            print("\nCoincidencias completas encontradas:")
            for idx, sim, text, conf in sorted(complete_matches, key=lambda x: x[1], reverse=True):
                x = data['left'][idx]
                y = data['top'][idx]
                print(f" - '{text}' en ({x}, {y}) con {sim:.1f}% de similitud, confianza: {conf}")
            
            # Ordenar por similitud y confianza
            complete_matches.sort(key=lambda x: (x[1], x[3]), reverse=True)
            
            # Verificar si la mejor coincidencia es suficientemente buena
            best_match = complete_matches[0]
            
            if best_match[1] >= min_confidence:
                idx = best_match[0]
                
                # Obtener coordenadas
                x = data['left'][idx]
                y = data['top'][idx]
                w = data['width'][idx]
                h = data['height'][idx]
                
                # Destacar la mejor coincidencia
                cv2.rectangle(debug_img, (x, y), (x + w, y + h), (0, 0, 255), 3)
                cv2.imwrite(os.path.join("imagenes", "best_match.png"), debug_img)
                
                # Calcular centro
                center_x = x + w // 2
                center_y = y + h // 2
                
                print(f"✅ Coincidencia completa aceptada para '{target_text}': '{best_match[2]}' en ({center_x}, {center_y}) "
                      f"con {best_match[1]:.1f}% de similitud y {best_match[3]:.1f}% de confianza")
                return (center_x, center_y)
        
        # Verificar coincidencias parciales si están permitidas y si se encontró "ventas"
        if allow_partial and partial_matches:
            print("\nCoincidencias parciales encontradas:")
            for idx, sim, text, conf in sorted(partial_matches, key=lambda x: x[1], reverse=True):
                x = data['left'][idx]
                y = data['top'][idx]
                print(f" - '{text}' en ({x}, {y}) con {sim:.1f}% de similitud, confianza: {conf}")
            
            # Ordenar por similitud y confianza
            partial_matches.sort(key=lambda x: (x[1], x[3]), reverse=True)
            
            # Usar la mejor coincidencia parcial
            best_match = partial_matches[0]
            
            if best_match[1] >= min_confidence:
                idx = best_match[0]
                
                # Obtener coordenadas
                x = data['left'][idx]
                y = data['top'][idx]
                w = data['width'][idx]
                h = data['height'][idx]
                
                # Destacar la mejor coincidencia parcial
                cv2.rectangle(debug_img, (x, y), (x + w, y + h), (0, 0, 255), 3)
                cv2.imwrite(os.path.join("imagenes", "best_partial_match.png"), debug_img)
                
                # Calcular centro
                center_x = x + w // 2
                center_y = y + h // 2
                
                print(f"✅ Coincidencia parcial aceptada para '{target_text}': '{best_match[2]}' en ({center_x}, {center_y}) "
                      f"con {best_match[1]:.1f}% de similitud y {best_match[3]:.1f}% de confianza")
                return (center_x, center_y)
            else:
                print(f"❌ Mejor coincidencia parcial tiene {best_match[1]:.1f}% de similitud, "
                      f"pero no alcanza el mínimo requerido de {min_confidence}%")
        
        # Si no hay buenas coincidencias con PSM 11, probar con PSM 6 (líneas de texto)
        print("Reintentando con PSM 6 (detección de líneas de texto)...")
        custom_config = '--oem 3 --psm 6'
        data = pytesseract.image_to_data(processed_img, output_type=pytesseract.Output.DICT, config=custom_config, lang='spa')
        
        # Reiniciar listas de coincidencias
        complete_matches = []
        partial_matches = []
        
        for i, text_line in enumerate(data['text']):
            if len(text_line.strip()) < min_length:
                continue
                
            cleaned_line = clean_text(text_line)
            
            if not cleaned_line.strip():
                continue
            
            x = data['left'][i]
            y = data['top'][i]
            w = data['width'][i]
            h = data['height'][i]
            conf = data['conf'][i]
            
            if conf < 55:
                continue
            
            # Calcular similitud con texto completo    
            clean_line_nospace = cleaned_line.lower().replace(" ", "")
            similarity = calculate_text_similarity(clean_line_nospace, clean_target)
            
            if similarity > 80:  # Alta similitud para coincidencia completa
                print(f"Línea: '{cleaned_line}', Confianza: {conf}, Similitud: {similarity:.1f}%")
                complete_matches.append((i, similarity, cleaned_line, conf))
            # Comprobar coincidencias parciales
            elif allow_partial:
                # Verificar si la línea contiene alguna de las palabras objetivo
                for target_word in target_words:
                    if target_word in clean_line_nospace and target_word == "ventas":
                        word_similarity = calculate_text_similarity(target_word, target_word)  # 100%
                        print(f"Línea parcial: '{cleaned_line}', Confianza: {conf}, Similitud: {word_similarity:.1f}% (palabra: {target_word})")
                        partial_matches.append((i, word_similarity, cleaned_line, conf))
                        break
        
        # Procesar resultados de PSM 6 - primero completos
        if complete_matches:
            print("\nCoincidencias completas encontradas con PSM 6:")
            for idx, sim, text, conf in sorted(complete_matches, key=lambda x: x[1], reverse=True):
                x = data['left'][idx]
                y = data['top'][idx]
                print(f" - '{text}' en ({x}, {y}) con {sim:.1f}% de similitud, confianza: {conf}")
            
            # Ordenar por similitud y confianza
            complete_matches.sort(key=lambda x: (x[1], x[3]), reverse=True)
            
            # Verificar si la mejor coincidencia es suficientemente buena
            best_match = complete_matches[0]
            
            if best_match[1] >= min_confidence:
                idx = best_match[0]
                
                # Obtener coordenadas
                x = data['left'][idx]
                y = data['top'][idx]
                w = data['width'][idx]
                h = data['height'][idx]
                
                # Calcular centro
                center_x = x + w // 2
                center_y = y + h // 2
                
                print(f"✅ Coincidencia completa aceptada con PSM 6 para '{target_text}': '{best_match[2]}' en ({center_x}, {center_y}) "
                      f"con {best_match[1]:.1f}% de similitud y {best_match[3]:.1f}% de confianza")
                return (center_x, center_y)
        
        # Luego parciales con PSM 6
        if allow_partial and partial_matches:
            print("\nCoincidencias parciales encontradas con PSM 6:")
            for idx, sim, text, conf in sorted(partial_matches, key=lambda x: x[1], reverse=True):
                x = data['left'][idx]
                y = data['top'][idx]
                print(f" - '{text}' en ({x}, {y}) con {sim:.1f}% de similitud, confianza: {conf}")
            
            # Ordenar por similitud y confianza
            partial_matches.sort(key=lambda x: (x[1], x[3]), reverse=True)
            
            # Verificar la mejor coincidencia parcial
            best_match = partial_matches[0]
            
            if best_match[1] >= min_confidence:
                idx = best_match[0]
                
                # Obtener coordenadas
                x = data['left'][idx]
                y = data['top'][idx]
                w = data['width'][idx]
                h = data['height'][idx]
                
                # Calcular centro
                center_x = x + w // 2
                center_y = y + h // 2
                
                print(f"✅ Coincidencia parcial aceptada con PSM 6 para '{target_text}': '{best_match[2]}' en ({center_x}, {center_y}) "
                      f"con {best_match[1]:.1f}% de similitud y {best_match[3]:.1f}% de confianza")
                return (center_x, center_y)
            else:
                print(f"❌ Mejor coincidencia parcial con PSM 6 tiene {best_match[1]:.1f}% de similitud, "
                      f"pero no alcanza el mínimo requerido de {min_confidence}%")
                
        # Si llegamos aquí, no se encontró una coincidencia suficientemente buena
        print(f"⚠️ No se encontró '{target_text}' con la confianza requerida.")
        return None
        
    except Exception as e:
        print(f"⚠️ Error buscando el texto: {str(e)}")
        import traceback
        traceback.print_exc()
        return None


def tap_screen(x, y):
    """Ejecuta un tap en las coordenadas especificadas"""
    try:
        # Ejecutar tap
        for attempt in range(3):
            try:
                subprocess.run(
                    f"adb shell input tap {x} {y}",
                    shell=True,
                    check=True,
                    timeout=5
                )
                print(f"✓ Tap exitoso en ({x}, {y})")
                sleep(0.5)  
                return True
            except subprocess.TimeoutExpired:
                print(f"Reintento {attempt+1} para tap en ({x}, {y})")
                sleep(1)
        
        raise Exception(f"Falló después de 3 intentos")
    except Exception as e:
        print(f"⚠️ Error al hacer tap en ({x}, {y}): {str(e)}")
        return False


def click_ver_ventas(min_confidence=60, allow_partial=True):
    """
    Busca y hace tap en el texto 'Ver ventas' si se encuentra con suficiente confianza.
    
    Args:
        min_confidence: Porcentaje mínimo de confianza para aceptar una coincidencia (0-100)
        allow_partial: Si es True, acepta coincidencias parciales como solo "ventas" 
                      cuando no se encuentra el texto completo
    
    Returns:
        bool: True si se encontró y se hizo tap, False en caso contrario
    """
    try:
        print("\n=== Buscando el texto 'Ver ventas' en tiempo real ===")
        
        # Capturar pantalla
        img = capture_screen()
        
        # Guardar captura original para referencia
        cv2.imwrite(os.path.join("imagenes", "screen_capture.png"), img)
        
        # Buscar texto y obtener coordenadas
        coords = find_text_and_click(img, target_text="Ver ventas", min_confidence=min_confidence)
        
        # Ejecutar tap SOLO si se encontraron coordenadas con suficiente confianza
        if coords:
            tap_screen(*coords)
            print("✅ Se encontró 'Ver ventas' y se realizó tap correctamente")
            return True
        else:
            print("⚠️ No se encontró 'Ver ventas' con suficiente confianza. No se realizó ningún tap.")
            return False
    except Exception as e:
        print(f"⚠️ Error en el proceso: {str(e)}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    # Usar umbral de confianza más bajo y permitir coincidencias parciales
    click_ver_ventas(min_confidence=60, allow_partial=True)