import cv2
import numpy as np
import subprocess
from time import sleep
import pytesseract
import os

# Crear carpeta de imágenes si no existe
if not os.path.exists("imagenes"):
    os.makedirs("imagenes")
    print("✅ Carpeta 'imagenes' creada correctamente")

# Configura Tesseract (Windows)
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'  # Comenta esta línea en Linux/Mac

# Función para capturar la pantalla en tiempo real
def capture_screen():
    """Captura la pantalla del dispositivo en tiempo real y la retorna como una imagen en memoria."""
    try:
        # Usar adb para capturar la pantalla
        screenshot = subprocess.run(
            "adb exec-out screencap -p", 
            shell=True, 
            stdout=subprocess.PIPE,
            check=True,
            timeout=10
        ).stdout

        # Convertir la captura de pantalla en formato binario a una imagen de OpenCV
        img = np.asarray(bytearray(screenshot), dtype=np.uint8)
        img = cv2.imdecode(img, cv2.IMREAD_COLOR)

        if img is None:
            raise Exception("Error al convertir la captura de pantalla en imagen")
        
        print("✅ Captura de pantalla exitosa")
        return img
    except subprocess.TimeoutExpired:
        raise Exception("Timeout al capturar pantalla")
    except Exception as e:
        raise Exception(f"Error capturando pantalla: {str(e)}")

def tap_screen(x, y):
    """Ejecuta un tap en las coordenadas especificadas"""
    try:
        # Ejecutar tap
        for attempt in range(3):
            try:
                subprocess.run(
                    f"adb shell input tap {x} {y}",
                    shell=True,
                    check=True,
                    timeout=5
                )
                print(f"✓ Tap exitoso en ({x}, {y})")
                sleep(0.5)  # Esperar un poco más para asegurar que el tap fue registrado
                return True
            except subprocess.TimeoutExpired:
                print(f"Reintento {attempt+1} para tap en ({x}, {y})")
                sleep(1)
        
        raise Exception(f"Falló después de 3 intentos")
    except Exception as e:
        print(f"⚠️ Error al hacer tap en ({x}, {y}): {str(e)}")
        return False

def close_keyboard():
    """Cierra el teclado virtual usando el botón Atrás"""
    try:
        subprocess.run(
            "adb shell input keyevent KEYCODE_BACK",
            shell=True,
            check=True,
            timeout=5
        )
        print("✅ Teclado cerrado exitosamente")
        return True
    except Exception as e:
        print(f"⚠️ Error al cerrar el teclado: {str(e)}")
        return False

def find_send_word_via_ocr(img):
    """
    Usar OCR para encontrar la palabra "ENVIAR" en la pantalla y hacer un tap en su centro.
    Si hay múltiples instancias, presionar la última.
    """
    # Convertir la imagen a escala de grises para mejorar el OCR
    gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    
    # Aplicar un filtro de suavizado para reducir el ruido
    smoothed_img = cv2.GaussianBlur(gray_img, (5, 5), 0)

    # Aplicar un umbral para mejorar la calidad del OCR
    _, thresh = cv2.threshold(smoothed_img, 150, 255, cv2.THRESH_BINARY)

    # Alternativa: Ajustar el contraste de la imagen
    # contraste_img = cv2.convertScaleAbs(thresh, alpha=1.5, beta=0)
    
    # Utilizar pytesseract para obtener el texto de la imagen
    text = pytesseract.image_to_string(thresh, lang='spa')

    print(f"Texto detectado: {text}")
    
    # Forzar búsqueda de la palabra "ENVIAR" en la imagen
    if "ENVIAR" in text:
        # Obtener las coordenadas del área donde aparece la palabra "ENVIAR"
        text_positions = pytesseract.image_to_boxes(thresh)
        
        enviar_positions = []  # Lista para almacenar las coordenadas de "ENVIAR"
        
        for b in text_positions.splitlines():
            b = b.split()
            if "ENVIAR" in b[0]:  # Buscamos la palabra completa "ENVIAR"
                x, y, w, h = int(b[1]), int(b[2]), int(b[3]), int(b[4])
                # Calculamos el centro del área de la palabra
                center_x = (x + w) // 2
                center_y = (y + h) // 2
                enviar_positions.append((center_x, center_y))
        
        # Si hay más de una posición de "ENVIAR", seleccionar la última
        if enviar_positions:
            # Seleccionar la última posición encontrada
            last_send_pos = enviar_positions[-1]
            print(f"Centro de la última ocurrencia de ENVIAR: {last_send_pos}")
            return last_send_pos

    return None

def clear_and_write_email():
    try:
        print("\n=== Limpiando el campo de correo y escribiendo un nuevo correo ===")
        
        # Capturar la pantalla en tiempo real
        img = capture_screen()
        
        # Guardar imagen original para debug
        cv2.imwrite(os.path.join("imagenes", "screen_capture.png"), img)
        
        # Identificar el campo de email y obtener coordenadas para ambos taps
        input_coords, end_coords = find_email_field_by_fixed_coords(img)
        
        # Primer tap - para seleccionar el campo
        print(f"Intentando primer tap en el campo de entrada: {input_coords}")
        if not tap_screen(*input_coords):
            print("❌ No se pudo hacer tap en el campo de correo")
            return False
        
        # Esperar para que se active el campo
        sleep(1)
        
        # Segundo tap - al final del texto existente
        print(f"Intentando segundo tap al final del campo: {end_coords}")
        if not tap_screen(*end_coords):
            print("❌ No se pudo hacer tap al final del campo de correo")
            return False
        
        sleep(1)
        
        # Eliminar todo el texto caracter por caracter usando backspace
        print("Eliminando caracteres con backspace...")
        for _ in range(50):  
            subprocess.run(
                "adb shell input keyevent KEYCODE_DEL",
                shell=True
            )
            sleep(0.05)  # Pausa entre pulsaciones
        
        print("✓ Texto borrado con múltiples DEL")
        sleep(0.5)
        
        # Escribir el nuevo correo
        #new_email = "pagos@ricoh-peru.com"
        new_email = "bryan.henry@outlook.es"
        subprocess.run(f'adb shell input text "{new_email}"', shell=True)
        print(f"✅ Nuevo correo ingresado: {new_email}")
        
        # Esperar un poco para que el texto se registre
        sleep(1)
        
        # NUEVO: Cerrar el teclado virtual después de escribir el correo
        print("Cerrando el teclado virtual...")
        close_keyboard()
        
        # Esperar un momento para que se cierre el teclado
        sleep(1)
        
        # Capturar la pantalla después de escribir el correo y cerrar el teclado
        img = capture_screen()
        
        # Buscar todas las ocurrencias de "ENVIAR" usando OCR
        send_word_coords = find_send_word_via_ocr(img)
        
        if send_word_coords:
            # Tap en la palabra ENVIAR
            print(f"Intentando tap en la palabra ENVIAR en {send_word_coords}")
            if not tap_screen(*send_word_coords):
                print("❌ No se pudo hacer tap en la palabra ENVIAR")
                return False
            
            # Para presionar todas las instancias de "ENVIAR", puedes hacer esto:
            all_send_positions = find_send_word_via_ocr(img)  # Usa la función actualizada
            if all_send_positions:
                for position in all_send_positions:
                    if not tap_screen(*position):
                        print(f"❌ No se pudo hacer tap en la palabra ENVIAR en {position}")
                        return False
        
        # Opcional: tomar una captura para verificar el resultado
        sleep(1)
        verification_img = capture_screen()
        cv2.imwrite(os.path.join("imagenes", "result_send_word.png"), verification_img)
        
        print("✅ Proceso completado exitosamente")
        return True
        
    except Exception as e:
        print(f"❌ Error: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

def find_email_field_by_fixed_coords(img):
    """
    Localiza el campo de email basado en coordenadas precisas de la imagen de referencia.
    """
    height, width = img.shape[:2]
    
    # Para visualización
    debug_img = img.copy()
    
    # Ajustar estas coordenadas según la posición real del campo en la imagen
    x_start = int(width * 0.05)
    x_end = int(width * 0.95)  # Un poco más a la derecha del borde izquierdo
    y_pos = int(height * 0.7)  # Posición vertical del campo de email
    
    # Dibujar rectángulo para ver dónde estamos apuntando
    cv2.rectangle(debug_img, 
                 (x_start, y_pos-30), 
                 (x_end, y_pos+30), 
                 (0, 255, 0), 2)
    
    # Guardar imagen con marcas
    cv2.imwrite(os.path.join("imagenes", "target_email_field.png"), debug_img)
    
    # Primer tap al final del campo de texto
    end_x = x_end - 5  # Un poco antes del borde derecho
    end_y = y_pos
    
    # El primer tap ahora se hace en el extremo derecho del campo de texto
    # Y el segundo tap será al final de la entrada del campo
    print(f"Punto de tap al final del campo de correo (más pegado a la derecha): ({end_x}, {end_y})")
    
    return (end_x, end_y), (end_x, end_y)  # Ambos taps serán al final del campo

if __name__ == "__main__":
    # Ejecuta la automatización con las coordenadas ajustadas
    clear_and_write_email()