import cv2
import numpy as np
import subprocess
from time import sleep
import pytesseract
import re
import os

# Crear carpeta de imágenes si no existe
if not os.path.exists("imagenes"):
    os.makedirs("imagenes")
    print("✅ Carpeta 'imagenes' creada correctamente")

# Configura Tesseract (Windows)
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'  # Comenta esta línea en Linux/Mac

# Función para capturar la pantalla en tiempo real
def capture_screen():
    """Captura la pantalla del dispositivo en tiempo real y la retorna como una imagen en memoria."""
    try:
        # Usar adb para capturar la pantalla
        screenshot = subprocess.run(
            "adb exec-out screencap -p", 
            shell=True, 
            stdout=subprocess.PIPE,
            check=True,
            timeout=10
        ).stdout

        # Convertir la captura de pantalla en formato binario a una imagen de OpenCV
        img = np.asarray(bytearray(screenshot), dtype=np.uint8)
        img = cv2.imdecode(img, cv2.IMREAD_COLOR)

        if img is None:
            raise Exception("Error al convertir la captura de pantalla en imagen")
        
        print("✅ Captura de pantalla exitosa")
        return img
    except subprocess.TimeoutExpired:
        raise Exception("Timeout al capturar pantalla")
    except Exception as e:
        raise Exception(f"Error capturando pantalla: {str(e)}")

def preprocess_image_for_ocr(img, debug=False):
    # Convertir la imagen a escala de grises
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    
    # Aplicar umbralización adaptativa
    binary = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, 
                                  cv2.THRESH_BINARY, 11, 2)
    
    # Aplicar operaciones morfológicas para mejorar la calidad
    kernel = np.ones((1, 1), np.uint8)
    binary = cv2.morphologyEx(binary, cv2.MORPH_CLOSE, kernel)
    
    if debug:
        cv2.imwrite(os.path.join("imagenes", "adaptive_threshold.png"), binary)
    
    return binary

def clean_text(text):
    """Limpiar el texto detectado para eliminar caracteres no deseados (como '©')"""
    # Usamos una expresión regular para eliminar caracteres no deseados
    cleaned_text = re.sub(r'[^\w\sáéíóúÁÉÍÓÚñÑ]', '', text)
    return cleaned_text

def find_text_and_click(img, target_text="REPORTE", min_length=1):
    try:
        # Preprocesar la imagen antes de usar OCR
        processed_img = preprocess_image_for_ocr(img, debug=True)

        # Guardar una copia con anotaciones para debugging
        debug_img = img.copy()
        
        # Usar OCR para obtener todas las palabras y sus ubicaciones
        custom_config = '--oem 3 --psm 11'
        data = pytesseract.image_to_data(processed_img, output_type=pytesseract.Output.DICT, config=custom_config, lang='spa')
        
        # Guardar ubicaciones de palabras encontradas para debugging
        print(f"Palabras encontradas por OCR: {len(data['text'])}")
        
        # Lista para almacenar potenciales coincidencias
        matches = []
        
        for i, word in enumerate(data['text']):
            # Filtrar entradas vacías y palabras demasiado cortas
            if len(word.strip()) < min_length:
                continue
                
            # Limpiar el texto para eliminar caracteres no deseados
            cleaned_word = clean_text(word)
            
            # Verificar que la palabra no sea vacía después de limpiarla
            if not cleaned_word.strip():
                continue
                
            # Mostrar todas las palabras detectadas para debugging
            x = data['left'][i]
            y = data['top'][i]
            w = data['width'][i]
            h = data['height'][i]
            conf = data['conf'][i]
            
            print(f"Palabra: '{cleaned_word}', Confianza: {conf}, Pos: ({x}, {y}, {w}, {h})")
            
            # Dibujar recuadro en la imagen de debug
            cv2.rectangle(debug_img, (x, y), (x + w, y + h), (0, 255, 0), 2)
            cv2.putText(debug_img, cleaned_word, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)
            
            # Comprobar coincidencia exacta
            if cleaned_word.lower() == target_text.lower():
                matches.append((i, 100, cleaned_word))  # 100% de coincidencia
            # Comprobar si la palabra contiene el texto objetivo o viceversa
            elif target_text.lower() in cleaned_word.lower():
                similarity = len(target_text) / len(cleaned_word) * 100
                matches.append((i, similarity, cleaned_word))
            elif cleaned_word.lower() in target_text.lower():
                similarity = len(cleaned_word) / len(target_text) * 100
                matches.append((i, similarity, cleaned_word))
        
        # Guarda la imagen con las anotaciones
        cv2.imwrite(os.path.join("imagenes", "debug_ocr.png"), debug_img)
        
        # Si encontramos coincidencias, ordénalas por nivel de similitud
        if matches:
            # Ordenar por nivel de similitud (descendente)
            matches.sort(key=lambda x: x[1], reverse=True)
            
            # Usar la coincidencia más alta
            best_match = matches[0]
            idx = best_match[0]
            
            # Obtener coordenadas
            x = data['left'][idx]
            y = data['top'][idx]
            w = data['width'][idx]
            h = data['height'][idx]
            
            # Dibujar el rectángulo de la mejor coincidencia
            cv2.rectangle(debug_img, (x, y), (x + w, y + h), (0, 0, 255), 3)
            cv2.imwrite(os.path.join("imagenes", "best_match.png"), debug_img)
            
            # Calcular el centro
            center_x = x + w // 2
            center_y = y + h // 2
            
            print(f"✅ Mejor coincidencia para '{target_text}': '{best_match[2]}' en ({center_x}, {center_y}) con {best_match[1]:.1f}% de similitud")
            return (center_x, center_y)
            
        # Si aún no encontramos nada, podemos hacer una estimación basada en patrones comunes de la interfaz
        # Esta es una solución alternativa basada en coordenadas conocidas para la ubicación de "REPORTE"
        print("⚠️ No se encontró el texto exacto. Usando ubicación estimada...")
        
        # Basado en la interfaz, "REPORTE" debería estar cerca de la parte inferior derecha de la pantalla
        screen_width = img.shape[1]
        screen_height = img.shape[0]
        
        # Estimar coordenadas (ajustar según el dispositivo y la UI)
        est_x = int(screen_width * 0.85)  # Aproximadamente en el lado derecho
        est_y = int(screen_height * 0.85)  # Aproximadamente en la parte inferior
        
        print(f"⚠️ Usando coordenadas estimadas: ({est_x}, {est_y})")
        return (est_x, est_y)
        
    except Exception as e:
        print(f"❌ Error buscando el texto: {str(e)}")
        import traceback
        traceback.print_exc()
        return None

def tap_screen(x, y):
    """Ejecuta un tap en las coordenadas especificadas"""
    try:
        # Ejecutar tap
        for attempt in range(3):
            try:
                subprocess.run(
                    f"adb shell input tap {x} {y}",
                    shell=True,
                    check=True,
                    timeout=5
                )
                print(f"✓ Tap exitoso en ({x}, {y})")
                sleep(0.5)  # Esperar un poco más para asegurar que el tap fue registrado
                return True
            except subprocess.TimeoutExpired:
                print(f"Reintento {attempt+1} para tap en ({x}, {y})")
                sleep(1)
        
        raise Exception(f"Falló después de 3 intentos")
    except Exception as e:
        print(f"⚠️ Error al hacer tap en ({x}, {y}): {str(e)}")
        return False

def click_reporte():
    try:
        print("\n=== Buscando el texto 'REPORTE' en tiempo real ===")
        
        # Capturar la pantalla en tiempo real
        img = capture_screen()
        
        # Guardar imagen original para debug
        cv2.imwrite(os.path.join("imagenes", "screen_capture.png"), img)
        
        # Buscar texto en la imagen
        coords = find_text_and_click(img, target_text="REPORTE")
        
        # Si se encuentra el texto, hacer clic
        if coords:
            tap_screen(*coords)
            print("✅ Proceso completado")
            return True
        else:
            print("❌ No se pudo encontrar el texto 'REPORTE'")
            return False
    except Exception as e:
        print(f"❌ Error: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    click_reporte()