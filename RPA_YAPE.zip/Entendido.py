import cv2
import numpy as np
import subprocess
from time import sleep
import pytesseract
import os

# Crear carpeta de imágenes si no existe
if not os.path.exists("imagenes"):
    os.makedirs("imagenes")
    print("✅ Carpeta 'imagenes' creada correctamente")

# Configura Tesseract (Windows)
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'  # Comenta esta línea en Linux/Mac

def capture_screen():
    """Captura la pantalla del dispositivo en tiempo real y la retorna como una imagen en memoria."""
    try:
        # Usar adb para capturar la pantalla
        screenshot = subprocess.run(
            "adb exec-out screencap -p", 
            shell=True, 
            stdout=subprocess.PIPE,
            check=True,
            timeout=10
        ).stdout

        # Convertir la captura de pantalla en formato binario a una imagen de OpenCV
        img = np.asarray(bytearray(screenshot), dtype=np.uint8)
        img = cv2.imdecode(img, cv2.IMREAD_COLOR)

        if img is None:
            raise Exception("Error al convertir la captura de pantalla en imagen")
        
        print("✅ Captura de pantalla exitosa")
        return img
    except subprocess.TimeoutExpired:
        raise Exception("Timeout al capturar pantalla")
    except Exception as e:
        raise Exception(f"Error capturando pantalla: {str(e)}")

def tap_screen(x, y):
    """Ejecuta un tap en las coordenadas especificadas"""
    try:
        # Ejecutar tap
        for attempt in range(3):
            try:
                subprocess.run(
                    f"adb shell input tap {x} {y}",
                    shell=True,
                    check=True,
                    timeout=5
                )
                print(f"✓ Tap exitoso en ({x}, {y})")
                sleep(0.5)  # Esperar un poco más para asegurar que el tap fue registrado
                return True
            except subprocess.TimeoutExpired:
                print(f"Reintento {attempt+1} para tap en ({x}, {y})")
                sleep(1)
        
        raise Exception(f"Falló después de 3 intentos")
    except Exception as e:
        print(f"⚠️ Error al hacer tap en ({x}, {y}): {str(e)}")
        return False

def find_entendido_button_via_ocr(img):
    """
    Usar OCR para encontrar la palabra "ENTENDIDO" en la pantalla y hacer un tap en su centro.
    """
    # Convertir la imagen a escala de grises para mejorar el OCR
    gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    
    # Aplicar un filtro de suavizado para reducir el ruido
    smoothed_img = cv2.GaussianBlur(gray_img, (5, 5), 0)

    # Aplicar un umbral para mejorar la calidad del OCR
    _, thresh = cv2.threshold(smoothed_img, 150, 255, cv2.THRESH_BINARY)
    
    # Guardar imagen preprocesada para debug
    cv2.imwrite(os.path.join("imagenes", "preprocessed_entendido.png"), thresh)
    
    # Utilizar pytesseract para obtener el texto y las posiciones
    data = pytesseract.image_to_data(thresh, lang='spa', output_type=pytesseract.Output.DICT)
    
    # Buscar la palabra "ENTENDIDO" en los resultados
    for i, text in enumerate(data['text']):
        if "ENTENDIDO" in text:
            # Obtener las coordenadas de la palabra
            x = data['left'][i]
            y = data['top'][i]
            w = data['width'][i]
            h = data['height'][i]
            
            # Calcular el centro del botón
            center_x = x + w // 2
            center_y = y + h // 2
            
            print(f"Palabra 'ENTENDIDO' encontrada en: ({center_x}, {center_y})")
            
            # Dibujar un rectángulo para debug
            debug_img = img.copy()
            cv2.rectangle(debug_img, (x, y), (x + w, y + h), (0, 255, 0), 2)
            cv2.imwrite(os.path.join("imagenes", "entendido_detected.png"), debug_img)
            
            return center_x, center_y
    
    # Método alternativo si el anterior falla
    # Buscar región verde/azul clara específica del botón ENTENDIDO
    print("Método OCR no encontró 'ENTENDIDO', intentando método alternativo...")
    
    # Filtrar por color aproximado del botón ENTENDIDO en la imagen (ajustar según el color real)
    # El color parece ser un verde azulado claro
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    # Rango para color turquesa/verde azulado
    lower_turquoise = np.array([75, 50, 50])  
    upper_turquoise = np.array([95, 255, 255])
    mask = cv2.inRange(hsv, lower_turquoise, upper_turquoise)
    
    # Buscar contornos en la máscara
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
    # Guardar imagen con máscara para debug
    cv2.imwrite(os.path.join("imagenes", "entendido_mask.png"), mask)
    
    # Si encontramos contornos, asumimos que el más grande corresponde al botón
    if contours:
        # Ordenar contornos por área (de mayor a menor)
        contours = sorted(contours, key=cv2.contourArea, reverse=True)
        
        # Obtener el rectángulo del contorno más grande
        x, y, w, h = cv2.boundingRect(contours[0])
        
        # Calcular el centro
        center_x = x + w // 2
        center_y = y + h // 2
        
        # Dibujar el contorno para debug
        debug_img = img.copy()
        cv2.rectangle(debug_img, (x, y), (x + w, y + h), (0, 0, 255), 2)
        cv2.imwrite(os.path.join("imagenes", "entendido_contour.png"), debug_img)
        
        print(f"Botón ENTENDIDO encontrado por método de color en: ({center_x}, {center_y})")
        return center_x, center_y
    
    # Si todo falla, usar coordenadas fijas basadas en la imagen proporcionada
    print("Métodos anteriores fallaron, usando coordenadas fijas...")
    height, width = img.shape[:2]
    # Basado en la posición observada en la imagen
    fixed_x = width // 2  # Centro horizontal de la pantalla
    fixed_y = int(height * 0.845)  # Aproximadamente donde está ENTENDIDO en la imagen
    
    print(f"Usando coordenadas fijas para ENTENDIDO: ({fixed_x}, {fixed_y})")
    return fixed_x, fixed_y

def tap_entendido_button():
    try:
        print("\n=== Buscando y presionando el botón ENTENDIDO ===")
        
        # Capturar la pantalla en tiempo real
        img = capture_screen()
        
        # Guardar imagen original para debug
        cv2.imwrite(os.path.join("imagenes", "screen_entendido.png"), img)
        
        # Buscar el botón ENTENDIDO en la pantalla
        button_coords = find_entendido_button_via_ocr(img)
        
        if button_coords:
            # Tap en el botón ENTENDIDO
            print(f"Intentando tap en el botón ENTENDIDO en {button_coords}")
            if tap_screen(*button_coords):
                print("✅ Botón ENTENDIDO presionado exitosamente")
                return True
            else:
                print("❌ No se pudo hacer tap en el botón ENTENDIDO")
                return False
        else:
            print("❌ No se pudo encontrar el botón ENTENDIDO en la pantalla")
            return False
        
    except Exception as e:
        print(f"❌ Error: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    # Ejecutar la función para presionar el botón ENTENDIDO
    tap_entendido_button()