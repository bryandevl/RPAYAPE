# -*- coding: utf-8 -*-
import cv2
import numpy as np
import subprocess
import pytesseract
import time
import traceback
import os

# Definimos la función tap_screen aquí mismo para eliminar la dependencia externa
def tap_screen(x, y):
    """Toca la pantalla en las coordenadas (x, y) usando ADB."""
    try:
        print(f"🖱️ Tocando la pantalla en ({x}, {y})...")
        adb_command = f"adb shell input tap {x} {y}"
        process = subprocess.run(
            adb_command,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=True,
            timeout=5
        )
        print("✅ Acción de tocar completada.")
        return True
    except subprocess.CalledProcessError as e:
        error_message = e.stderr.decode('utf-8', errors='ignore').strip()
        print(f"❌ Error ejecutando tap via ADB: {error_message}")
        return False
    except Exception as e:
        print(f"❌ Error inesperado durante tap: {str(e)}")
        return False

# --- Configuración ---
try:
    pytesseract.pytesseract.tesseract_cmd = 'tesseract'
    tesseract_version = pytesseract.get_tesseract_version()
    print(f"ℹ️ Usando Tesseract desde el PATH (Versión: {tesseract_version}).")
except pytesseract.TesseractNotFoundError:
    print("⚠️ Tesseract no encontrado en el PATH, intentando ruta específica para Windows...")
    windows_path = r'C:\Program Files\Tesseract-OCR\tesseract.exe'
    pytesseract.pytesseract.tesseract_cmd = windows_path
    try:
        tesseract_version = pytesseract.get_tesseract_version()
        print(f"ℹ️ Usando Tesseract desde '{windows_path}' (Versión: {tesseract_version}).")
    except pytesseract.TesseractNotFoundError:
        print(f"❌ ERROR: Tesseract no encontrado en '{windows_path}' ni en el PATH.")
        print("❌ Por favor, instala Tesseract (asegúrate de incluir el paquete de idioma 'spa')")
        print("❌ y/o ajusta la ruta 'pytesseract.pytesseract.tesseract_cmd' en el script.")
        exit()
except Exception as e:
     print(f"❌ ERROR inesperado configurando Tesseract: {e}")
     exit()

# --- Funciones ---

def capture_screen():
    """Captura la pantalla del dispositivo en tiempo real vía ADB y la retorna como una imagen OpenCV."""
    print("🔄 Capturando pantalla vía ADB...")
    adb_command = "adb exec-out screencap -p"
    try:
        process = subprocess.run(
            adb_command,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=True,
            timeout=15
        )
        screenshot_bytes = process.stdout

        if not screenshot_bytes:
            stderr_output = process.stderr.decode('utf-8', errors='ignore').strip()
            raise Exception(f"ADB no devolvió datos de imagen (stdout vacío). ¿Dispositivo conectado y autorizado? Error ADB: {stderr_output}")

        img_np_arr = np.frombuffer(screenshot_bytes, np.uint8)
        img = cv2.imdecode(img_np_arr, cv2.IMREAD_COLOR)

        if img is None and screenshot_bytes.endswith(b'\r\n'):
             print("ℹ️ Detectado CRLF extra al final, intentando decodificar de nuevo...")
             img_np_arr = np.frombuffer(screenshot_bytes[:-2], np.uint8)
             img = cv2.imdecode(img_np_arr, cv2.IMREAD_COLOR)

        if img is None:
             print(f"⚠️ Datos recibidos (primeros 100 bytes): {screenshot_bytes[:100]}")
             print(f"⚠️ Datos recibidos (últimos 10 bytes): {screenshot_bytes[-10:]}")
             raise Exception("Error al decodificar la imagen de la captura de pantalla. ¿Formato inesperado?")

        print(f"✅ Captura de pantalla exitosa (Dimensiones: {img.shape[1]}x{img.shape[0]})")
        return img

    except subprocess.TimeoutExpired:
        raise Exception(f"Timeout esperando la captura de pantalla de ADB (comando: '{adb_command}').")
    except subprocess.CalledProcessError as e:
        error_message = e.stderr.decode('utf-8', errors='ignore').strip()
        if "device unauthorized" in error_message or "device offline" in error_message:
             raise Exception(f"Error ADB: Dispositivo no autorizado u offline. Por favor, verifica la conexión y la autorización en el dispositivo. Mensaje: {error_message}")
        elif "no devices/emulators found" in error_message:
             raise Exception(f"Error ADB: No se encontraron dispositivos/emuladores. Verifica la conexión. Mensaje: {error_message}")
        else:
             raise Exception(f"Error ejecutando ADB screencap (comando: '{adb_command}'). Código de error: {e.returncode}. Mensaje: {error_message}")
    except FileNotFoundError:
         raise Exception("Error: El comando 'adb' no se encontró. Asegúrate de que ADB esté instalado y en el PATH del sistema.")
    except Exception as e:
        print(f"❌ Error inesperado durante la captura de pantalla:")
        traceback.print_exc()
        raise Exception(f"Error inesperado capturando pantalla: {str(e)}")

def find_turquoise_button(img):
    """
    Detecta específicamente el botón turquesa 'ENVIAR'.
    IMPORTANTE: Se asegura de seleccionar el botón VERDE y no el botón blanco.
    """
    print("🔍 Buscando el botón turquesa 'ENVIAR'...")
    
    # Crear directorio para imágenes de depuración si no existe
    debug_dir = "debug_images"
    os.makedirs(debug_dir, exist_ok=True)
    
    # Convertir a HSV para mejor detección de colores
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    
    # Rango para el color turquesa/verde azulado (ajustado específicamente para el botón ENVIAR)
    lower_turquoise = np.array([160, 100, 100])  # Valores HSV para turquesa/verde
    upper_turquoise = np.array([180, 255, 255])
    
    # Rango alternativo (más amplio)
    lower_turquoise2 = np.array([80, 70, 70])
    upper_turquoise2 = np.array([110, 255, 255])
    
    # Crear máscaras para ambos rangos
    mask1 = cv2.inRange(hsv, lower_turquoise, upper_turquoise)
    mask2 = cv2.inRange(hsv, lower_turquoise2, upper_turquoise2)
    
    # Combinar máscaras
    mask = cv2.bitwise_or(mask1, mask2)
    
    # Aplicar operaciones morfológicas
    kernel = np.ones((5,5), np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
    
    # Guardar la máscara para depuración
    try:
        cv2.imwrite(f"{debug_dir}/turquoise_mask.png", mask)
    except Exception as e:
        print(f"⚠️ No se pudo guardar máscara: {e}")
    
    # Encontrar contornos
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
    # Filtrar contornos
    min_area = 3000
    button_candidates = []
    
    # Imagen para depuración
    debug_img = img.copy()
    
    print(f"ℹ️ Encontrados {len(contours)} contornos turquesa, filtrando por área > {min_area} px²")
    
    for contour in contours:
        area = cv2.contourArea(contour)
        if area > min_area:
            x, y, w, h = cv2.boundingRect(contour)
            aspect_ratio = float(w) / h
            
            # Botones suelen ser más anchos que altos
            if 2.0 < aspect_ratio < 10.0:
                center_x = x + w // 2
                center_y = y + h // 2
                
                # Extraer la región del botón para análisis de color
                roi = img[y:y+h, x:x+w]
                
                # Calcular el color promedio en la ROI (en BGR)
                avg_color = cv2.mean(roi)[:3]  # BGR
                
                # Verificar si es verdaderamente verde/turquesa (no blanco)
                # Un botón turquesa tendrá componentes G (verde) y B (azul) más altas que R (rojo)
                is_green = (avg_color[1] > avg_color[0]) and (avg_color[1] > 100)
                
                button_candidates.append({
                    'center': (center_x, center_y),
                    'area': area,
                    'rect': (x, y, w, h),
                    'avg_color': avg_color,
                    'is_green': is_green,
                    'y_pos': y  # Para ordenar por posición vertical
                })
                
                # Color para el recuadro según si es verde o no
                box_color = (0, 255, 0) if is_green else (0, 0, 255)
                
                # Dibujar en la imagen de depuración
                cv2.rectangle(debug_img, (x, y), (x + w, y + h), box_color, 3)
                cv2.circle(debug_img, (center_x, center_y), 10, (255, 0, 0), -1)
                cv2.putText(debug_img, f"Area: {area}", (x, y-10),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.6, box_color, 2)
                
                # Añadir texto indicando si es verde
                status = "VERDE" if is_green else "NO VERDE"
                cv2.putText(debug_img, status, (x, y+h+20),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.6, box_color, 2)
    
    # Guardar imagen de depuración
    try:
        cv2.imwrite(f"{debug_dir}/turquoise_buttons.png", debug_img)
        print(f"💾 Imagen de detección de botones turquesa guardada")
    except Exception as e:
        print(f"⚠️ No se pudo guardar imagen: {e}")
    
    if not button_candidates:
        print("❌ No se encontraron botones turquesa que cumplan los criterios.")
        return None
    
    # Filtrar para mantener solo los botones verdes
    green_buttons = [btn for btn in button_candidates if btn['is_green']]
    
    if not green_buttons:
        print("⚠️ No se encontraron botones verdes, buscando alternativas...")
        # Si no hay botones verdes, usar todos los candidatos
        green_buttons = button_candidates
    
    # Ordenar primero por posición vertical (de arriba a abajo)
    green_buttons.sort(key=lambda x: x['y_pos'])
    
    # IMPORTANTE: Para la interfaz que vemos en las imágenes, 
    # el botón ENVIAR está por encima del botón CANCELAR
    # pero para asegurarnos, vamos a usar OCR para confirmar
    
    # Lista para mantener botones con texto verificado
    verified_buttons = []
    
    for i, btn in enumerate(green_buttons):
        x, y, w, h = btn['rect']
        button_roi = img[y:y+h, x:x+w]
        
        # Convertir a escala de grises
        gray_roi = cv2.cvtColor(button_roi, cv2.COLOR_BGR2GRAY)
        
        # Umbral para destacar texto blanco
        _, thresh_roi = cv2.threshold(gray_roi, 200, 255, cv2.THRESH_BINARY)
        
        # Guardar ROI para depuración
        try:
            cv2.imwrite(f"{debug_dir}/button_roi_{i}.png", button_roi)
            cv2.imwrite(f"{debug_dir}/button_thresh_{i}.png", thresh_roi)
        except Exception as e:
            print(f"⚠️ No se pudo guardar ROI: {e}")
        
        # Aplicar OCR para verificar texto
        try:
            configs = [
                r'-l spa --oem 3 --psm 7',  # Línea única
                r'-l spa --oem 3 --psm 8'   # Palabra única
            ]
            
            for config in configs:
                text = pytesseract.image_to_string(thresh_roi, config=config).strip().upper()
                print(f"ℹ️ Botón #{i+1} - Texto detectado: '{text}' (config: {config})")
                
                # Verificar si contiene ENVIAR
                if "ENVIAR" in text or "ENV" in text or "NVIA" in text:
                    btn['text'] = "ENVIAR"
                    btn['text_confidence'] = 1.0
                    verified_buttons.append(btn)
                    print(f"✅ Botón #{i+1} verificado como 'ENVIAR'")
                    break
                
                # Verificar si contiene CANCELAR
                elif "CANCELAR" in text or "CANCEL" in text or "CANC" in text:
                    btn['text'] = "CANCELAR"
                    btn['text_confidence'] = 0.0  # No queremos este botón
                    print(f"ℹ️ Botón #{i+1} identificado como 'CANCELAR' (ignorado)")
                    break
        except Exception as e:
            print(f"⚠️ Error en OCR para botón #{i+1}: {e}")
    
    # Si encontramos botones con texto ENVIAR verificado, usar esos
    if verified_buttons:
        best_button = verified_buttons[0]
        print(f"✅ Botón 'ENVIAR' verificado por OCR seleccionado")
    else:
        # Si no pudimos verificar mediante OCR, usar heurística
        print("⚠️ No se pudo verificar texto por OCR, usando heurística basada en color...")
        
        # Ordenar botones por "verde-ness" (preferir el más verde)
        green_buttons.sort(key=lambda x: (x['avg_color'][1] - x['avg_color'][0]), reverse=True)
        
        best_button = green_buttons[0]
        
        # Seleccionar el botón SUPERIOR verde (asumiendo que ENVIAR está arriba, CANCELAR abajo)
        for btn in green_buttons:
            if btn['is_green'] and btn['y_pos'] < best_button['y_pos']:
                best_button = btn
    
    button_center = best_button['center']
    print(f"✅ Botón turquesa seleccionado en {button_center}")
    
    # Dibujar el botón seleccionado
    selected_img = img.copy()
    x, y, w, h = best_button['rect']
    cv2.rectangle(selected_img, (x, y), (x + w, y + h), (0, 255, 255), 5)
    cv2.circle(selected_img, button_center, 15, (0, 0, 255), -1)
    cv2.putText(selected_img, "SELECCIONADO", (x, y-20),
               cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 255), 2)
    
    try:
        cv2.imwrite(f"{debug_dir}/selected_button.png", selected_img)
    except Exception as e:
        print(f"⚠️ No se pudo guardar imagen: {e}")
    
    return button_center

def find_specific_green_button(img):
    """
    Enfoque directo para encontrar específicamente el botón verde turquesa ENVIAR
    que se muestra en la interfaz de las imágenes proporcionadas.
    """
    print("🔍 Buscando específicamente el botón verde turquesa 'ENVIAR'...")
    
    # Crear directorio para imágenes de depuración
    debug_dir = "debug_images"
    os.makedirs(debug_dir, exist_ok=True)
    
    # Definir la parte de la pantalla donde debemos buscar
    height, width = img.shape[:2]
    
    # Basado en las imágenes, buscar en el tercio medio vertical
    roi_top = int(height * 0.4)  
    roi_bottom = int(height * 0.7)
    roi = img[roi_top:roi_bottom, :]
    
    # Convertir a HSV
    hsv_roi = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
    
    # Rango de color verde turquesa optimizado
    lower_turquoise = np.array([70, 100, 100])  
    upper_turquoise = np.array([100, 255, 255])
    
    # Crear máscara
    mask = cv2.inRange(hsv_roi, lower_turquoise, upper_turquoise)
    
    # Operaciones morfológicas
    kernel = np.ones((5,5), np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
    
    # Guardar máscara para depuración
    try:
        cv2.imwrite(f"{debug_dir}/specific_green_mask.png", mask)
    except Exception as e:
        print(f"⚠️ No se pudo guardar máscara: {e}")
    
    # Encontrar contornos
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
    print(f"ℹ️ Encontrados {len(contours)} contornos verdes en la región de interés")
    
    # Si no hay contornos, volver
    if not contours:
        print("❌ No se encontraron áreas verdes en la zona esperada.")
        return None
    
    # Imagen para depuración
    debug_img = img.copy()
    cv2.rectangle(debug_img, (0, roi_top), (width, roi_bottom), (255, 0, 0), 2)
    
    # Filtrar contornos por área
    valid_contours = []
    for contour in contours:
        area = cv2.contourArea(contour)
        if area > 10000:  # Área mínima ajustada para este caso
            x, y, w, h = cv2.boundingRect(contour)
            
            # Convertir coordenadas relativas a absolutas
            abs_y = y + roi_top
            
            valid_contours.append({
                'area': area,
                'rect': (x, abs_y, w, h),
                'center': (x + w//2, abs_y + h//2)
            })
            
            # Dibujar en imagen de depuración
            cv2.rectangle(debug_img, (x, abs_y), (x + w, abs_y + h), (0, 255, 0), 3)
            cv2.circle(debug_img, (x + w//2, abs_y + h//2), 10, (0, 0, 255), -1)
            cv2.putText(debug_img, f"Área: {area}", (x, abs_y-10),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
    
    # Guardar imagen de depuración
    try:
        cv2.imwrite(f"{debug_dir}/specific_green_detection.png", debug_img)
    except Exception as e:
        print(f"⚠️ No se pudo guardar imagen: {e}")
    
    if not valid_contours:
        print("❌ No se encontraron áreas verdes de tamaño adecuado.")
        return None
    
    # Ordenar por área descendente
    valid_contours.sort(key=lambda x: x['area'], reverse=True)
    
    # IMPORTANTE: Si hay dos botones, necesitamos el SUPERIOR (ENVIAR), no el inferior (CANCELAR)
    # Si hay dos o más botones de tamaño similar, tomar el que está más arriba
    
    if len(valid_contours) > 1:
        # Verificar si los dos primeros botones tienen áreas similares
        area1 = valid_contours[0]['area']
        area2 = valid_contours[1]['area']
        
        if abs(area1 - area2) / max(area1, area2) < 0.3:  # Si las áreas son similares (dentro del 30%)
            # Ordenar por posición Y (de arriba a abajo)
            valid_contours.sort(key=lambda x: x['rect'][1])
            print("ℹ️ Detectados dos botones de tamaño similar, seleccionando el superior (ENVIAR)")
    
    # Seleccionar el mejor botón
    best_contour = valid_contours[0]
    
    # Verificar si tiene características del botón ENVIAR
    x, y, w, h = best_contour['rect']
    button_roi = img[y:y+h, x:x+w]
    
    # Verificar el color promedio (debe ser verde/turquesa, no blanco)
    avg_color = cv2.mean(button_roi)[:3]  # BGR
    is_green = (avg_color[1] > avg_color[0]) and (avg_color[1] > 100)
    
    if not is_green:
        print("⚠️ El contorno detectado no parece tener color verde dominante.")
        
        # En este caso, buscar explícitamente el botón más verde entre los detectados
        most_green = None
        max_green_value = 0
        
        for contour in valid_contours:
            x, y, w, h = contour['rect']
            roi = img[y:y+h, x:x+w]
            color = cv2.mean(roi)[:3]  # BGR
            green_value = color[1] - max(color[0], color[2])  # G - max(R,B)
            
            if green_value > max_green_value:
                max_green_value = green_value
                most_green = contour
        
        if most_green:
            best_contour = most_green
            print("ℹ️ Seleccionando el contorno con componente verde más fuerte")
    
    # Obtener centro final
    center_x, center_y = best_contour['center']
    
    # Crear imagen final de depuración
    final_img = img.copy()
    x, y, w, h = best_contour['rect']
    cv2.rectangle(final_img, (x, y), (x + w, y + h), (0, 255, 255), 5)
    cv2.circle(final_img, (center_x, center_y), 15, (0, 0, 255), -1)
    cv2.putText(final_img, "BOTÓN ENVIAR", (x, y-20),
               cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 255), 2)
    
    try:
        cv2.imwrite(f"{debug_dir}/final_button_selected.png", final_img)
    except Exception as e:
        print(f"⚠️ No se pudo guardar imagen: {e}")
    
    print(f"✅ Botón ENVIAR encontrado en ({center_x}, {center_y})")
    return center_x, center_y

def main():
    """Flujo principal para detectar y presionar específicamente el botón ENVIAR verde."""
    start_time = time.time()
    print("\n" + "="*10 + " Inicio del Script: Detectar y Tocar 'ENVIAR' (Corregido) " + "="*10)
    
    # Crear directorio para imágenes de depuración
    debug_dir = "debug_images"
    os.makedirs(debug_dir, exist_ok=True)
    print(f"ℹ️ Imágenes de depuración se guardarán en: {debug_dir}/")

    max_attempts = 3
    delay_between_attempts = 2  # segundos
    
    for attempt in range(1, max_attempts + 1):
        print(f"\n>>> INTENTO {attempt} DE {max_attempts} <<<")
        
        try:
            img = capture_screen()
            if img is None:
                print("❌ No se pudo obtener la imagen de la pantalla.")
                if attempt < max_attempts:
                    print(f"Esperando {delay_between_attempts} segundos antes del siguiente intento...")
                    time.sleep(delay_between_attempts)
                continue

            # Guardar captura original para depuración
            try:
                cv2.imwrite(f"{debug_dir}/screen_attempt_{attempt}.png", img)
                print(f"💾 Captura de pantalla guardada")
            except Exception as img_err:
                print(f"⚠️ No se pudo guardar captura: {img_err}")

            # NUEVO: Usar método optimizado para encontrar específicamente el botón ENVIAR verde
            button_coords = find_specific_green_button(img)
            
            # Si el método específico falla, intentar con el método genérico
            if not button_coords:
                print("⚠️ Método específico falló, intentando con método alternativo...")
                button_coords = find_turquoise_button(img)

            if button_coords:
                x, y = button_coords
                print("-" * 30)
                print(f"🖱️ Tocando en coordenadas: ({x}, {y})")
                if tap_screen(x, y):
                    print("-" * 30)
                    print("✅ Proceso completado exitosamente.")
                    return True
                else:
                    print("❌ Falló la acción de TAP en las coordenadas encontradas.")
                    if attempt < max_attempts:
                        print(f"Esperando {delay_between_attempts} segundos antes del siguiente intento...")
                        time.sleep(delay_between_attempts)
            else:
                print("-" * 30)
                print("❌ No se encontró un botón 'ENVIAR' adecuado en la pantalla.")
                if attempt < max_attempts:
                    print(f"Esperando {delay_between_attempts} segundos antes del siguiente intento...")
                    time.sleep(delay_between_attempts)

        except Exception as e:
            print(f"\n❌ ERROR EN INTENTO {attempt}: {str(e)}")
            print("-" * 60)
            traceback.print_exc()
            print("-" * 60)
            if attempt < max_attempts:
                print(f"Esperando {delay_between_attempts} segundos antes del siguiente intento...")
                time.sleep(delay_between_attempts)
    
    print("\n❌ Se agotaron todos los intentos sin éxito.")
    end_time = time.time()
    print(f"\n--- Tiempo total de ejecución: {end_time - start_time:.2f} segundos ---")
    return False

if __name__ == "__main__":
    execution_successful = main()
    if execution_successful:
        print("\nSCRIPT FINALIZADO CON ÉXITO")
    else:
        print("\nSCRIPT FINALIZADO CON ERRORES O SIN ENCONTRAR EL BOTÓN")