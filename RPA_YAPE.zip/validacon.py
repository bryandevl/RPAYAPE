import cv2
import numpy as np
import subprocess
from time import sleep
import pytesseract
import time
import logging
from datetime import datetime
import os

# Crear carpeta de imágenes si no existe
if not os.path.exists("imagenes"):
    os.makedirs("imagenes")
    print("✅ Carpeta 'imagenes' creada correctamente")

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("session_timeout_detector.log"),
        logging.StreamHandler()
    ]
)

# Configurar también un logger específico para monitor_entendido.log (requerido por el script principal)
monitor_logger = logging.getLogger('monitor_entendido')
monitor_handler = logging.FileHandler("monitor_entendido.log")
monitor_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
monitor_logger.addHandler(monitor_handler)
monitor_logger.setLevel(logging.INFO)

# Configura Tesseract (Windows)
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'  # Comenta esta línea en Linux/Mac

def capture_screen():
    """Captura la pantalla del dispositivo en tiempo real y la retorna como una imagen en memoria."""
    try:
        # Usar adb para capturar la pantalla
        screenshot = subprocess.run(
            "adb exec-out screencap -p", 
            shell=True, 
            stdout=subprocess.PIPE,
            check=True,
            timeout=10
        ).stdout

        # Convertir la captura de pantalla en formato binario a una imagen de OpenCV
        img = np.asarray(bytearray(screenshot), dtype=np.uint8)
        img = cv2.imdecode(img, cv2.IMREAD_COLOR)

        if img is None:
            raise Exception("Error al convertir la captura de pantalla en imagen")
        
        return img
    except subprocess.TimeoutExpired:
        logging.error("Timeout al capturar pantalla")
        monitor_logger.error("Timeout al capturar pantalla")
        return None
    except Exception as e:
        logging.error(f"Error capturando pantalla: {str(e)}")
        monitor_logger.error(f"Error capturando pantalla: {str(e)}")
        return None

def tap_screen(x, y):
    """Ejecuta un tap en las coordenadas especificadas"""
    try:
        # Ejecutar tap
        for attempt in range(3):
            try:
                subprocess.run(
                    f"adb shell input tap {x} {y}",
                    shell=True,
                    check=True,
                    timeout=5
                )
                logging.info(f"Tap exitoso en ({x}, {y})")
                monitor_logger.info(f"Tap exitoso en ({x}, {y})")
                sleep(0.5)  # Esperar un poco más para asegurar que el tap fue registrado
                return True
            except subprocess.TimeoutExpired:
                logging.warning(f"Reintento {attempt+1} para tap en ({x}, {y})")
                monitor_logger.warning(f"Reintento {attempt+1} para tap en ({x}, {y})")
                sleep(1)
        
        raise Exception(f"Falló después de 3 intentos")
    except Exception as e:
        logging.error(f"Error al hacer tap en ({x}, {y}): {str(e)}")
        monitor_logger.error(f"Error al hacer tap en ({x}, {y}): {str(e)}")
        return False

def has_session_timeout_message(text):
    """
    Verifica si el texto contiene el mensaje específico de tiempo de sesión terminado.
    """
    required_phrases = [
        "tiempo de tu sesión ha",
        "terminado",
        "inténtalo nuevamente"
    ]
    
    # Convertir texto a minúsculas para comparación insensible a mayúsculas
    text_lower = text.lower()
    
    # Verificar si al menos dos de las frases están presentes
    matches = sum(1 for phrase in required_phrases if phrase in text_lower)
    
    # Log detallado de las coincidencias encontradas
    for phrase in required_phrases:
        if phrase in text_lower:
            logging.info(f"Frase encontrada: '{phrase}'")
            monitor_logger.info(f"Frase encontrada: '{phrase}'")
        else:
            logging.info(f"Frase NO encontrada: '{phrase}'")
            monitor_logger.info(f"Frase NO encontrada: '{phrase}'")
    
    if matches >= 2:
        logging.info(f"Mensaje específico de sesión terminada confirmado ({matches} frases coincidentes)")
        monitor_logger.info(f"Mensaje específico de sesión terminada confirmado ({matches} frases coincidentes)")
        return True
    else:
        logging.info(f"Mensaje de sesión terminada NO confirmado (solo {matches} frases coincidentes)")
        monitor_logger.info(f"Mensaje de sesión terminada NO confirmado (solo {matches} frases coincidentes)")
        return False

def find_entendido_in_session_message(img):
    """
    Detecta si hay un mensaje de 'tiempo de sesión terminado' y el botón ENTENDIDO asociado.
    Devuelve las coordenadas del botón ENTENDIDO solo si se confirma el mensaje específico.
    """
    # Crear una copia para visualización/debug
    debug_img = img.copy()
    
    # Convertir la imagen a escala de grises
    gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    
    # Aplicar filtros para mejorar la calidad del OCR
    blur = cv2.GaussianBlur(gray_img, (5, 5), 0)
    _, thresh = cv2.threshold(blur, 150, 255, cv2.THRESH_BINARY)
    
    # Guardar imagen preprocesada para debug
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    cv2.imwrite(os.path.join("imagenes", f"preprocessed_{timestamp}.png"), thresh)
    
    # Extraer todo el texto de la imagen
    full_text = pytesseract.image_to_string(thresh, lang='spa')
    logging.info(f"Texto extraído completo:\n{full_text}")
    monitor_logger.info(f"Texto extraído completo:\n{full_text}")
    
    # PASO 1: Verificar si el texto contiene el mensaje específico de sesión terminada
    if not has_session_timeout_message(full_text):
        logging.info("No se detectó el mensaje específico de 'tiempo de sesión terminado'")
        monitor_logger.info("No se detectó el mensaje específico de 'tiempo de sesión terminado'")
        return None
    
    # PASO 2: Verificar si "ENTENDIDO" está en el texto
    if "ENTENDIDO" not in full_text:
        logging.info("Palabra 'ENTENDIDO' no encontrada en el texto")
        monitor_logger.info("Palabra 'ENTENDIDO' no encontrada en el texto")
        return None
    
    # PASO 3: Si ambas condiciones se cumplen, obtener la posición del botón ENTENDIDO
    logging.info("CONFIRMADO: Se detectó tanto el mensaje específico como la palabra ENTENDIDO")
    monitor_logger.info("CONFIRMADO: Se detectó tanto el mensaje específico como la palabra ENTENDIDO")
    
    # Obtener información detallada sobre la posición del texto
    data = pytesseract.image_to_data(thresh, lang='spa', output_type=pytesseract.Output.DICT)
    
    # Buscar "ENTENDIDO" y obtener sus coordenadas
    entendido_coords = None
    confidence_threshold = 60  # Confianza mínima de OCR en %
    
    for i, word in enumerate(data['text']):
        # Verificar si la palabra es "ENTENDIDO" y tiene confianza suficiente
        if "ENTENDIDO" in word and data['conf'][i] >= confidence_threshold:
            x = data['left'][i]
            y = data['top'][i]
            w = data['width'][i]
            h = data['height'][i]
            conf = data['conf'][i]
            
            # Dibujar un rectángulo para visualización
            cv2.rectangle(debug_img, (x, y), (x+w, y+h), (0, 255, 0), 2)
            
            # Calcular el centro del botón
            center_x = x + w // 2
            center_y = y + h // 2
            
            logging.info(f"Botón ENTENDIDO encontrado en ({center_x}, {center_y}) con confianza {conf}%")
            monitor_logger.info(f"Botón ENTENDIDO encontrado en ({center_x}, {center_y}) con confianza {conf}%")
            entendido_coords = (center_x, center_y)
            
            # Guardar imagen con el botón detectado
            cv2.imwrite(os.path.join("imagenes", f"entendido_found_{timestamp}.png"), debug_img)
            
            # Devolver solo si estamos seguros que tanto el mensaje como el botón son correctos
            return entendido_coords
    
    logging.info("No se pudo determinar la posición exacta del botón ENTENDIDO")
    monitor_logger.info("No se pudo determinar la posición exacta del botón ENTENDIDO")
    return None

def check_and_tap_session_timeout():
    """
    Verifica si existe el mensaje específico de tiempo de sesión terminado con el botón ENTENDIDO,
    y solo si ambos están presentes, presiona el botón ENTENDIDO.
    """
    logging.info("=== Iniciando verificación de mensaje de sesión terminada ===")
    monitor_logger.info("=== Iniciando verificación de mensaje de sesión terminada ===")
    
    try:
        # Capturar la pantalla
        img = capture_screen()
        if img is None:
            logging.error("No se pudo capturar la pantalla")
            monitor_logger.error("No se pudo capturar la pantalla")
            return False
        
        # Guardar captura inicial para referencia
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        cv2.imwrite(os.path.join("imagenes", f"screen_capture_{timestamp}.png"), img)
        
        # Verificar si hay un mensaje de sesión terminada con botón ENTENDIDO
        button_coords = find_entendido_in_session_message(img)
        
        if button_coords:
            logging.info("Se encontró el mensaje específico de sesión terminada con el botón ENTENDIDO")
            monitor_logger.info("Se encontró el mensaje específico de sesión terminada con el botón ENTENDIDO")
            
            # Hacer tap en el botón ENTENDIDO
            if tap_screen(*button_coords):
                logging.info("[EXITO] Botón ENTENDIDO presionado correctamente")
                monitor_logger.info("[EXITO] Botón ENTENDIDO presionado correctamente")
                return True
            else:
                logging.error("No se pudo hacer tap en el botón ENTENDIDO")
                monitor_logger.error("No se pudo hacer tap en el botón ENTENDIDO")
                return False
        else:
            logging.info("No se encontró el mensaje específico de sesión terminada con el botón ENTENDIDO")
            monitor_logger.info("No se encontró el mensaje específico de sesión terminada con el botón ENTENDIDO")
            return False
    
    except Exception as e:
        logging.error(f"Error durante la verificación: {str(e)}")
        monitor_logger.error(f"Error durante la verificación: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

# Funciones adicionales para compatibilidad con el script principal
def validate():
    """Función de compatibilidad para el script principal"""
    return check_and_tap_session_timeout()

def validate_session():
    """Función de compatibilidad para el script principal"""
    return check_and_tap_session_timeout()

def check_session():
    """Función de compatibilidad para el script principal"""
    return check_and_tap_session_timeout()

def run():
    """Función de compatibilidad para el script principal"""
    return check_and_tap_session_timeout()

def check():
    """Función de compatibilidad para el script principal"""
    return check_and_tap_session_timeout()

def execute():
    """Función de compatibilidad para el script principal"""
    return check_and_tap_session_timeout()

def process():
    """Función de compatibilidad para el script principal"""
    return check_and_tap_session_timeout()

def main():
    """Función principal que verifica y maneja el timeout de sesión"""
    logging.info("Ejecutando validación de timeout de sesión...")
    monitor_logger.info("Ejecutando validación de timeout de sesión...")
    result = check_and_tap_session_timeout()
    if result:
        logging.info("Timeout de sesión detectado y manejado correctamente")
        monitor_logger.info("Timeout de sesión detectado y manejado correctamente")
    else:
        logging.info("No se detectó timeout de sesión o no se pudo manejar")
        monitor_logger.info("No se detectó timeout de sesión o no se pudo manejar")
    return result

# Ejecutar si este script se llama directamente
if __name__ == "__main__":
    main()